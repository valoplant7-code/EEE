'use client'

import { MessageSquare, BarChart3, PieChart } from 'lucide-react'
import { cn } from '@/lib/utils'

interface NavTabsProps {
  activeTab: 'notes' | 'data' | 'stats'
  onTabChange: (tab: 'notes' | 'data' | 'stats') => void
}

export function NavTabs({ activeTab, onTabChange }: NavTabsProps) {
  return (
    <nav className="flex gap-1 rounded-lg bg-secondary p-1">
      <button
        onClick={() => onTabChange('notes')}
        className={cn(
          'flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors',
          activeTab === 'notes'
            ? 'bg-background text-foreground shadow-sm'
            : 'text-muted-foreground hover:text-foreground'
        )}
      >
        <MessageSquare className="h-4 w-4" />
        <span className="hidden sm:inline">Notes</span>
      </button>
      <button
        onClick={() => onTabChange('data')}
        className={cn(
          'flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors',
          activeTab === 'data'
            ? 'bg-background text-foreground shadow-sm'
            : 'text-muted-foreground hover:text-foreground'
        )}
      >
        <BarChart3 className="h-4 w-4" />
        <span className="hidden sm:inline">Matches</span>
      </button>
      <button
        onClick={() => onTabChange('stats')}
        className={cn(
          'flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors',
          activeTab === 'stats'
            ? 'bg-background text-foreground shadow-sm'
            : 'text-muted-foreground hover:text-foreground'
        )}
      >
        <PieChart className="h-4 w-4" />
        <span className="hidden sm:inline">Stats</span>
      </button>
    </nav>
  )
}
