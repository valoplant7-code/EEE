'use client'

import { useState, useEffect } from 'react'
import { MessageSquare, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { AddNoteForm } from './add-note-form'
import { NotesList } from './notes-list'
import { createClient } from '@/lib/supabase/client'
import type { ScrimNote } from '@/lib/types'

export function ScrimNotesPage() {
  const [notes, setNotes] = useState<ScrimNote[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    fetchNotes()
  }, [])

  async function fetchNotes() {
    setLoading(true)
    const { data, error } = await supabase
      .from('scrim_notes')
      .select('*')
      .order('created_at', { ascending: false })

    if (error) {
      console.error('Error fetching notes:', error)
    } else {
      setNotes(data || [])
    }
    setLoading(false)
  }

  async function handleAddNote(note: {
    round_number: number
    our_score: number
    their_score: number
    content: string
    map?: string
    vod_url?: string
    author: string
  }) {
    const { data, error } = await supabase
      .from('scrim_notes')
      .insert([note])
      .select()
      .single()

    if (error) {
      console.error('Error adding note:', error)
    } else if (data) {
      setNotes((prev) => [data, ...prev])
    }
  }

  async function handleDeleteNote(id: string) {
    const { error } = await supabase
      .from('scrim_notes')
      .delete()
      .eq('id', id)

    if (error) {
      console.error('Error deleting note:', error)
    } else {
      setNotes((prev) => prev.filter((n) => n.id !== id))
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/20">
            <MessageSquare className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Scrim Notes</h1>
            <p className="text-sm text-muted-foreground">
              Manage scrim notes from Discord or add them manually. Notes use scoreline format (e.g., &quot;5-3 nice eco round&quot;).
            </p>
          </div>
        </div>
        <Button 
          onClick={fetchNotes}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <RefreshCw className="mr-2 h-4 w-4" />
          Fetch from Discord
        </Button>
      </div>

      <AddNoteForm onSubmit={handleAddNote} />

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <RefreshCw className="h-6 w-6 animate-spin text-primary" />
        </div>
      ) : (
        <NotesList notes={notes} onDeleteNote={handleDeleteNote} />
      )}
    </div>
  )
}
