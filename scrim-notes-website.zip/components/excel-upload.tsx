'use client'

import React from "react"
import { useState, useRef } from 'react'
import { Upload, FileSpreadsheet, Check, AlertCircle, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import * as XLSX from 'xlsx'

interface RoundData {
  map: string
  team: string
  round: number
  side: 'ATK' | 'DEF'
  pistolAtk?: boolean
  pistolDef?: boolean
  fk?: boolean // First Kill
  fkWin?: boolean // FK round Win
  fd?: boolean // First Death
  fdWin?: boolean // FD round Win
  spikePlant?: boolean
  roundWin?: boolean
  site?: 'A' | 'B'
  ecoRound?: boolean
  ecoWin?: boolean
  antiEco?: boolean
  antiEcoWin?: boolean
}

interface ParsedMatch {
  team: string
  map: string
  date: string
  roundsWon: number
  roundsLost: number
  side?: string
  rounds: RoundData[]
  stats: {
    fkPercent?: number
    fkWinPercent?: number
    fdPercent?: number
    fdWinPercent?: number
    plantPercent?: number
    postPercent?: number
    retakePercent?: number
    ecoWinPercent?: number
    antiEcoWinPercent?: number
    atkWinPercent?: number
    defWinPercent?: number
  }
  players: {
    name: string
    agent: string
    acs: number
    kills: number
    deaths: number
    assists: number
    firstKills: number
  }[]
}

interface ExcelUploadProps {
  onImport: (matches: ParsedMatch[]) => Promise<void>
}

export function ExcelUpload({ onImport }: ExcelUploadProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [parsedData, setParsedData] = useState<ParsedMatch[]>([])
  const [showPreview, setShowPreview] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  function handleDragOver(e: React.DragEvent) {
    e.preventDefault()
    setIsDragging(true)
  }

  function handleDragLeave() {
    setIsDragging(false)
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault()
    setIsDragging(false)
    const files = e.dataTransfer.files
    if (files.length > 0) {
      processFile(files[0])
    }
  }

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files
    if (files && files.length > 0) {
      processFile(files[0])
    }
  }

  function parseBoolean(val: unknown): boolean | undefined {
    if (val === undefined || val === null || val === '') return undefined
    if (typeof val === 'boolean') return val
    const str = String(val).toUpperCase().trim()
    if (str === 'TRUE' || str === '1' || str === 'YES') return true
    if (str === 'FALSE' || str === '0' || str === 'NO') return false
    return undefined
  }

  function parsePercent(val: unknown): number | undefined {
    if (val === undefined || val === null || val === '') return undefined
    if (typeof val === 'number') {
      // Already a decimal or percentage
      return val > 1 ? val : val * 100
    }
    const str = String(val).replace('%', '').trim()
    const num = parseFloat(str)
    if (isNaN(num)) return undefined
    return num
  }

  async function processFile(file: File) {
    if (!file.name.match(/\.(xlsx|xls)$/i)) {
      setError('Please upload an Excel file (.xlsx or .xls)')
      return
    }

    setIsProcessing(true)
    setError(null)

    try {
      const data = await file.arrayBuffer()
      const workbook = XLSX.read(data, { type: 'array' })
      
      // Get first sheet
      const sheetName = workbook.SheetNames[0]
      const sheet = workbook.Sheets[sheetName]
      
      if (!sheet) {
        throw new Error('Could not find data sheet')
      }

      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { header: 1 }) as unknown[][]
      
      // Find header row (row with Map, Team, Round, Side columns)
      let headerRowIdx = -1
      let colIndex: Record<string, number> = {}
      
      for (let i = 0; i < Math.min(rows.length, 5); i++) {
        const row = rows[i] as string[]
        if (!row) continue
        
        for (let j = 0; j < row.length; j++) {
          const cell = String(row[j] || '').toLowerCase().trim()
          if (cell === 'map' || cell === 'team' || cell === 'round' || cell === 'side') {
            // Found header row
            headerRowIdx = i
            row.forEach((h, idx) => {
              const key = String(h || '').toLowerCase().trim()
              if (key) colIndex[key] = idx
            })
            break
          }
        }
        if (headerRowIdx >= 0) break
      }

      if (headerRowIdx < 0) {
        throw new Error('Could not find header row with Map/Team/Round/Side columns')
      }

      // Parse round data
      const roundsByMatch: Map<string, RoundData[]> = new Map()
      const statsByMatch: Map<string, ParsedMatch['stats']> = new Map()
      
      let currentMap = ''
      let currentTeam = ''

      for (let rowIdx = headerRowIdx + 1; rowIdx < rows.length; rowIdx++) {
        const row = rows[rowIdx] as (string | number | boolean | undefined)[]
        if (!row || row.length === 0) continue

        // Get map and team (they might be merged cells, so remember last value)
        const mapVal = row[colIndex['map']]
        const teamVal = row[colIndex['team']]
        
        if (mapVal) currentMap = String(mapVal)
        if (teamVal) currentTeam = String(teamVal)
        
        const round = Number(row[colIndex['round']])
        const side = String(row[colIndex['side']] || '').toUpperCase()
        
        if (!round || !side || !currentMap || !currentTeam) continue

        const matchKey = `${currentMap}|${currentTeam}`

        const roundData: RoundData = {
          map: currentMap,
          team: currentTeam,
          round,
          side: side === 'ATK' ? 'ATK' : 'DEF',
          pistolAtk: parseBoolean(row[colIndex['pistol atk']] ?? row[colIndex['pistatk']]),
          pistolDef: parseBoolean(row[colIndex['pistol def']] ?? row[colIndex['pistatdef']]),
          fk: parseBoolean(row[colIndex['fk']]),
          fkWin: parseBoolean(row[colIndex['fk w%']] ?? row[colIndex['fkwin']]),
          fd: parseBoolean(row[colIndex['fd']]),
          fdWin: parseBoolean(row[colIndex['fd round win']] ?? row[colIndex['fdwin']]),
          spikePlant: parseBoolean(row[colIndex['spike plant']] ?? row[colIndex['plant']]),
          roundWin: parseBoolean(row[colIndex['round win']] ?? row[colIndex['win']]),
          site: (String(row[colIndex['site']] || '').toUpperCase() === 'A' ? 'A' : 
                 String(row[colIndex['site']] || '').toUpperCase() === 'B' ? 'B' : undefined),
          ecoRound: parseBoolean(row[colIndex['eco']] ?? row[colIndex['eco round']]),
          ecoWin: parseBoolean(row[colIndex['eco round win']] ?? row[colIndex['ecowin']]),
          antiEco: parseBoolean(row[colIndex['anti eco']] ?? row[colIndex['antieco']]),
          antiEcoWin: parseBoolean(row[colIndex['anti eco round win']] ?? row[colIndex['antiecowin']])
        }

        if (!roundsByMatch.has(matchKey)) {
          roundsByMatch.set(matchKey, [])
        }
        roundsByMatch.get(matchKey)!.push(roundData)

        // Capture aggregate stats if present in this row (usually calculated columns)
        const existingStats = statsByMatch.get(matchKey) || {}
        statsByMatch.set(matchKey, {
          ...existingStats,
          fkPercent: parsePercent(row[colIndex['fk%']]) ?? existingStats.fkPercent,
          fkWinPercent: parsePercent(row[colIndex['fk w%']]) ?? existingStats.fkWinPercent,
          fdPercent: parsePercent(row[colIndex['fd%']]) ?? existingStats.fdPercent,
          fdWinPercent: parsePercent(row[colIndex['fd w%']]) ?? existingStats.fdWinPercent,
          plantPercent: parsePercent(row[colIndex['plant%']]) ?? existingStats.plantPercent,
          postPercent: parsePercent(row[colIndex['post %']] ?? row[colIndex['post%']]) ?? existingStats.postPercent,
          retakePercent: parsePercent(row[colIndex['retake %']] ?? row[colIndex['retake%']]) ?? existingStats.retakePercent,
          ecoWinPercent: parsePercent(row[colIndex['ecow%']] ?? row[colIndex['eco%']]) ?? existingStats.ecoWinPercent,
          antiEcoWinPercent: parsePercent(row[colIndex['a_ecow%']] ?? row[colIndex['antiecow%']]) ?? existingStats.antiEcoWinPercent,
          atkWinPercent: parsePercent(row[colIndex['win%']]) ?? existingStats.atkWinPercent,
        })
      }

      // Convert to matches
      const matches: ParsedMatch[] = []
      
      for (const [matchKey, rounds] of roundsByMatch.entries()) {
        const [map, team] = matchKey.split('|')
        
        // Calculate wins/losses from round data
        const roundsWon = rounds.filter(r => r.roundWin === true).length
        const roundsLost = rounds.filter(r => r.roundWin === false).length
        
        // If no explicit round win data, try to infer from total rounds
        const totalRounds = rounds.length
        const inferredWon = roundsWon || Math.floor(totalRounds / 2)
        const inferredLost = roundsLost || (totalRounds - inferredWon)

        matches.push({
          team,
          map,
          date: new Date().toISOString().split('T')[0],
          roundsWon: roundsWon || inferredWon,
          roundsLost: roundsLost || inferredLost,
          rounds,
          stats: statsByMatch.get(matchKey) || {},
          players: []
        })
      }

      if (matches.length === 0) {
        throw new Error('No valid match data found. Make sure your sheet has Map, Team, Round, and Side columns.')
      }

      setParsedData(matches)
      setShowPreview(true)
    } catch (err) {
      console.error('Error parsing Excel:', err)
      setError(err instanceof Error ? err.message : 'Failed to parse Excel file')
    } finally {
      setIsProcessing(false)
      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }
    }
  }

  async function handleConfirmImport() {
    setIsProcessing(true)
    try {
      await onImport(parsedData)
      setParsedData([])
      setShowPreview(false)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to import data')
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <>
      <Card className="border-border bg-card">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg text-card-foreground">
            <FileSpreadsheet className="h-5 w-5 text-primary" />
            Import from Excel
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div
            className={`relative flex flex-col items-center justify-center gap-3 rounded-lg border-2 border-dashed p-8 transition-colors ${
              isDragging
                ? 'border-primary bg-primary/10'
                : 'border-border hover:border-primary/50'
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <Upload className={`h-10 w-10 ${isDragging ? 'text-primary' : 'text-muted-foreground'}`} />
            <div className="text-center">
              <p className="text-sm text-foreground">
                Drag and drop your Excel file here, or{' '}
                <button
                  type="button"
                  className="text-primary underline hover:text-primary/80"
                  onClick={() => fileInputRef.current?.click()}
                >
                  browse
                </button>
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                Supports round-by-round format with Map, Team, Round, Side columns
              </p>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls"
              className="hidden"
              onChange={handleFileSelect}
            />
            {isProcessing && (
              <div className="absolute inset-0 flex items-center justify-center rounded-lg bg-background/80">
                <div className="flex items-center gap-2 text-primary">
                  <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                  Processing...
                </div>
              </div>
            )}
          </div>

          {error && (
            <div className="mt-3 flex items-center gap-2 rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
              <AlertCircle className="h-4 w-4" />
              {error}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-h-[80vh] max-w-4xl overflow-y-auto bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle>Preview Import Data</DialogTitle>
            <DialogDescription>
              Found {parsedData.length} matches to import. Review and confirm.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3">
            {parsedData.map((match, idx) => (
              <div
                key={idx}
                className="rounded-lg border border-border bg-secondary/50 p-4"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="rounded bg-primary/20 px-2 py-0.5 text-sm font-medium text-primary">
                      {match.map}
                    </span>
                    <span className="font-medium text-foreground">vs {match.team}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`font-mono text-lg font-bold ${
                        match.roundsWon > match.roundsLost
                          ? 'text-green-500'
                          : match.roundsWon < match.roundsLost
                          ? 'text-red-500'
                          : 'text-yellow-500'
                      }`}
                    >
                      {match.roundsWon}-{match.roundsLost}
                    </span>
                  </div>
                </div>
                
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
                  <div className="rounded bg-background px-2 py-1">
                    <span className="text-muted-foreground">Rounds: </span>
                    <span className="text-foreground">{match.rounds.length}</span>
                  </div>
                  <div className="rounded bg-background px-2 py-1">
                    <span className="text-muted-foreground">ATK: </span>
                    <span className="text-foreground">
                      {match.rounds.filter(r => r.side === 'ATK').length} rounds
                    </span>
                  </div>
                  <div className="rounded bg-background px-2 py-1">
                    <span className="text-muted-foreground">DEF: </span>
                    <span className="text-foreground">
                      {match.rounds.filter(r => r.side === 'DEF').length} rounds
                    </span>
                  </div>
                  {match.stats.fkPercent !== undefined && (
                    <div className="rounded bg-background px-2 py-1">
                      <span className="text-muted-foreground">FK%: </span>
                      <span className="text-foreground">{match.stats.fkPercent.toFixed(1)}%</span>
                    </div>
                  )}
                </div>

                {/* Round visualization */}
                <div className="mt-3 flex flex-wrap gap-1">
                  {match.rounds.slice(0, 24).map((round, rIdx) => (
                    <div
                      key={rIdx}
                      className={`flex h-6 w-6 items-center justify-center rounded text-xs font-medium ${
                        round.roundWin === true
                          ? 'bg-green-500/20 text-green-500'
                          : round.roundWin === false
                          ? 'bg-red-500/20 text-red-500'
                          : 'bg-muted text-muted-foreground'
                      }`}
                      title={`R${round.round} ${round.side} ${round.roundWin ? 'W' : round.roundWin === false ? 'L' : '?'}`}
                    >
                      {round.round}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button
              variant="outline"
              onClick={() => setShowPreview(false)}
              className="bg-transparent"
            >
              <X className="mr-2 h-4 w-4" />
              Cancel
            </Button>
            <Button onClick={handleConfirmImport} disabled={isProcessing}>
              {isProcessing ? (
                <>
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                  Importing...
                </>
              ) : (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Import {parsedData.length} Matches
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
