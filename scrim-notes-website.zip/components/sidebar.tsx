'use client'

import { cn } from '@/lib/utils'
import {
  BarChart3,
  Calendar,
  Lightbulb,
  Upload,
  FileEdit,
  PenLine,
  Video,
  MessageSquare,
  Map,
  ChevronLeft,
  ChevronRight
} from 'lucide-react'
import { Button } from '@/components/ui/button'

export type PageType = 
  | 'metrics'
  | 'calendar'
  | 'insights'
  | 'upload'
  | 'edit-data'
  | 'manual-input'
  | 'vods'
  | 'notes'
  | 'veto'

interface SidebarProps {
  activePage: PageType
  onPageChange: (page: PageType) => void
  collapsed: boolean
  onCollapsedChange: (collapsed: boolean) => void
}

const navItems = [
  {
    section: 'ANALYTICS',
    items: [
      { id: 'metrics' as const, label: 'Metrics Dashboard', icon: BarChart3 },
      { id: 'calendar' as const, label: 'Calendar', icon: Calendar },
      { id: 'insights' as const, label: 'Insights', icon: Lightbulb },
    ]
  },
  {
    section: 'DATA ENTRY',
    items: [
      { id: 'upload' as const, label: 'Upload Data', icon: Upload },
      { id: 'edit-data' as const, label: 'Edit Data', icon: FileEdit },
      { id: 'manual-input' as const, label: 'Manual Match Input', icon: PenLine },
      { id: 'vods' as const, label: 'Add VODs', icon: Video },
      { id: 'notes' as const, label: 'Scrim Notes', icon: MessageSquare },
    ]
  },
  {
    section: 'MATCH PREP',
    items: [
      { id: 'veto' as const, label: 'Map Veto Analysis', icon: Map },
    ]
  }
]

export function Sidebar({ activePage, onPageChange, collapsed, onCollapsedChange }: SidebarProps) {
  return (
    <aside className={cn(
      "flex h-screen flex-col border-r border-border bg-card transition-all duration-300",
      collapsed ? "w-16" : "w-64"
    )}>
      <div className="flex items-center gap-3 border-b border-border p-4">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary font-bold text-primary-foreground">
          GE
        </div>
        {!collapsed && (
          <span className="font-semibold text-foreground">Scrims Dashboard</span>
        )}
      </div>

      <nav className="flex-1 overflow-y-auto p-2">
        {navItems.map((section) => (
          <div key={section.section} className="mb-4">
            {!collapsed && (
              <p className="mb-2 px-3 text-xs font-medium text-muted-foreground">
                {section.section}
              </p>
            )}
            <div className="space-y-1">
              {section.items.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onPageChange(item.id)}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                    activePage === item.id
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  )}
                >
                  <item.icon className="h-4 w-4 shrink-0" />
                  {!collapsed && <span>{item.label}</span>}
                </button>
              ))}
            </div>
          </div>
        ))}
      </nav>

      <div className="border-t border-border p-2">
        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-center"
          onClick={() => onCollapsedChange(!collapsed)}
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>
    </aside>
  )
}
