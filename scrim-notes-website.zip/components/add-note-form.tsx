'use client'

import React from "react"

import { useState } from 'react'
import { Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { VALORANT_MAPS } from '@/lib/types'

interface AddNoteFormProps {
  onSubmit: (note: {
    round_number: number
    our_score: number
    their_score: number
    content: string
    map?: string
    vod_url?: string
    author: string
  }) => void
}

export function AddNoteForm({ onSubmit }: AddNoteFormProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [roundNumber, setRoundNumber] = useState('')
  const [ourScore, setOurScore] = useState('')
  const [theirScore, setTheirScore] = useState('')
  const [content, setContent] = useState('')
  const [map, setMap] = useState('')
  const [vodUrl, setVodUrl] = useState('')
  const [author, setAuthor] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!roundNumber || !ourScore || !theirScore || !content || !author) return

    onSubmit({
      round_number: parseInt(roundNumber),
      our_score: parseInt(ourScore),
      their_score: parseInt(theirScore),
      content,
      map: map || undefined,
      vod_url: vodUrl || undefined,
      author
    })

    setRoundNumber('')
    setOurScore('')
    setTheirScore('')
    setContent('')
    setMap('')
    setVodUrl('')
    setIsOpen(false)
  }

  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="flex items-center justify-between">
        <button
          className="flex items-center gap-2 text-foreground"
          onClick={() => setIsOpen(!isOpen)}
        >
          <Plus className="h-4 w-4" />
          <span className="font-medium">Add Manual Note</span>
        </button>
        {!isOpen && (
          <Button onClick={() => setIsOpen(true)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
            New Note
          </Button>
        )}
      </div>

      {isOpen && (
        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            <div className="space-y-2">
              <Label htmlFor="round">Round #</Label>
              <Input
                id="round"
                type="number"
                min="1"
                max="30"
                value={roundNumber}
                onChange={(e) => setRoundNumber(e.target.value)}
                placeholder="1"
                className="bg-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ourScore">Our Score</Label>
              <Input
                id="ourScore"
                type="number"
                min="0"
                max="13"
                value={ourScore}
                onChange={(e) => setOurScore(e.target.value)}
                placeholder="0"
                className="bg-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="theirScore">Their Score</Label>
              <Input
                id="theirScore"
                type="number"
                min="0"
                max="13"
                value={theirScore}
                onChange={(e) => setTheirScore(e.target.value)}
                placeholder="0"
                className="bg-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="map">Map</Label>
              <Select value={map} onValueChange={setMap}>
                <SelectTrigger className="bg-input">
                  <SelectValue placeholder="Select map" />
                </SelectTrigger>
                <SelectContent>
                  {VALORANT_MAPS.map((m) => (
                    <SelectItem key={m} value={m}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Note Content</Label>
            <Input
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="e.g., nice eco round, bad rotation timing..."
              className="bg-input"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="author">Author</Label>
              <Input
                id="author"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                placeholder="Your name"
                className="bg-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="vod">VOD URL (optional)</Label>
              <Input
                id="vod"
                value={vodUrl}
                onChange={(e) => setVodUrl(e.target.value)}
                placeholder="https://..."
                className="bg-input"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" className="bg-primary text-primary-foreground">
              Save Note
            </Button>
          </div>
        </form>
      )}
    </div>
  )
}
