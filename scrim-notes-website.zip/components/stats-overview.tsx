'use client'

import { TrendingUp, TrendingDown, Target, Skull, Swords, Map } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import type { ScrimMatch, PlayerStat } from '@/lib/types'

interface StatsOverviewProps {
  matches: ScrimMatch[]
  playerStats: PlayerStat[]
}

export function StatsOverview({ matches, playerStats }: StatsOverviewProps) {
  const wins = matches.filter(m => m.result === 'win').length
  const losses = matches.filter(m => m.result === 'loss').length
  const winRate = matches.length > 0 ? Math.round((wins / matches.length) * 100) : 0

  const totalRoundsWon = matches.reduce((acc, m) => acc + m.our_score, 0)
  const totalRoundsLost = matches.reduce((acc, m) => acc + m.enemy_score, 0)
  const roundDiff = totalRoundsWon - totalRoundsLost

  // Map performance
  const mapStats = matches.reduce((acc, match) => {
    if (!acc[match.map]) {
      acc[match.map] = { wins: 0, losses: 0, draws: 0 }
    }
    acc[match.map][match.result === 'win' ? 'wins' : match.result === 'loss' ? 'losses' : 'draws']++
    return acc
  }, {} as Record<string, { wins: number; losses: number; draws: number }>)

  // Player averages
  const playerAverages = playerStats.reduce((acc, stat) => {
    if (!acc[stat.player_name]) {
      acc[stat.player_name] = { 
        games: 0, 
        kills: 0, 
        deaths: 0, 
        assists: 0, 
        acs: 0, 
        adr: 0,
        first_kills: 0,
        first_deaths: 0
      }
    }
    acc[stat.player_name].games++
    acc[stat.player_name].kills += stat.kills
    acc[stat.player_name].deaths += stat.deaths
    acc[stat.player_name].assists += stat.assists
    acc[stat.player_name].acs += stat.acs
    acc[stat.player_name].adr += stat.adr
    acc[stat.player_name].first_kills += stat.first_kills
    acc[stat.player_name].first_deaths += stat.first_deaths
    return acc
  }, {} as Record<string, { games: number; kills: number; deaths: number; assists: number; acs: number; adr: number; first_kills: number; first_deaths: number }>)

  const sortedPlayers = Object.entries(playerAverages)
    .map(([name, stats]) => ({
      name,
      avgKD: stats.deaths > 0 ? (stats.kills / stats.deaths).toFixed(2) : stats.kills.toFixed(2),
      avgACS: Math.round(stats.acs / stats.games),
      avgADR: Math.round(stats.adr / stats.games),
      fkfd: stats.first_kills - stats.first_deaths,
      games: stats.games
    }))
    .sort((a, b) => b.avgACS - a.avgACS)

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-border bg-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Win Rate</CardTitle>
            {winRate >= 50 ? (
              <TrendingUp className="h-4 w-4 text-chart-4" />
            ) : (
              <TrendingDown className="h-4 w-4 text-destructive" />
            )}
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{winRate}%</div>
            <p className="text-xs text-muted-foreground">
              {wins}W - {losses}L ({matches.length} games)
            </p>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Round Diff</CardTitle>
            <Target className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${roundDiff >= 0 ? 'text-chart-4' : 'text-destructive'}`}>
              {roundDiff >= 0 ? '+' : ''}{roundDiff}
            </div>
            <p className="text-xs text-muted-foreground">
              {totalRoundsWon} won / {totalRoundsLost} lost
            </p>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Matches Played</CardTitle>
            <Swords className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{matches.length}</div>
            <p className="text-xs text-muted-foreground">
              Across {Object.keys(mapStats).length} maps
            </p>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Best Map</CardTitle>
            <Map className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            {Object.keys(mapStats).length > 0 ? (
              <>
                <div className="text-2xl font-bold text-foreground">
                  {Object.entries(mapStats).sort((a, b) => 
                    (b[1].wins / (b[1].wins + b[1].losses)) - (a[1].wins / (a[1].wins + a[1].losses))
                  )[0]?.[0] || 'N/A'}
                </div>
                <p className="text-xs text-muted-foreground">
                  Highest win rate
                </p>
              </>
            ) : (
              <>
                <div className="text-2xl font-bold text-foreground">N/A</div>
                <p className="text-xs text-muted-foreground">No matches yet</p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Map Performance */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="text-lg">Map Performance</CardTitle>
        </CardHeader>
        <CardContent>
          {Object.keys(mapStats).length === 0 ? (
            <p className="py-4 text-center text-muted-foreground">No match data yet</p>
          ) : (
            <div className="space-y-3">
              {Object.entries(mapStats)
                .sort((a, b) => (b[1].wins + b[1].losses) - (a[1].wins + a[1].losses))
                .map(([map, stats]) => {
                  const total = stats.wins + stats.losses + stats.draws
                  const wr = total > 0 ? Math.round((stats.wins / total) * 100) : 0
                  return (
                    <div key={map} className="flex items-center gap-4">
                      <div className="w-24 font-medium text-foreground">{map}</div>
                      <div className="flex-1">
                        <div className="h-2 overflow-hidden rounded-full bg-secondary">
                          <div
                            className="h-full bg-primary"
                            style={{ width: `${wr}%` }}
                          />
                        </div>
                      </div>
                      <div className="w-16 text-right text-sm text-muted-foreground">
                        {stats.wins}W-{stats.losses}L
                      </div>
                      <div className={`w-12 text-right text-sm font-medium ${wr >= 50 ? 'text-chart-4' : 'text-destructive'}`}>
                        {wr}%
                      </div>
                    </div>
                  )
                })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Player Stats */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="text-lg">Player Averages</CardTitle>
        </CardHeader>
        <CardContent>
          {sortedPlayers.length === 0 ? (
            <p className="py-4 text-center text-muted-foreground">No player data yet</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-left text-muted-foreground">
                    <th className="pb-3">Player</th>
                    <th className="pb-3 text-right">Games</th>
                    <th className="pb-3 text-right">Avg K/D</th>
                    <th className="pb-3 text-right">Avg ACS</th>
                    <th className="pb-3 text-right">Avg ADR</th>
                    <th className="pb-3 text-right">FK/FD Diff</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedPlayers.map((player) => (
                    <tr key={player.name} className="border-b border-border/50">
                      <td className="py-3 font-medium text-foreground">{player.name}</td>
                      <td className="py-3 text-right text-muted-foreground">{player.games}</td>
                      <td className={`py-3 text-right font-medium ${parseFloat(player.avgKD) >= 1 ? 'text-chart-4' : 'text-destructive'}`}>
                        {player.avgKD}
                      </td>
                      <td className="py-3 text-right text-foreground">{player.avgACS}</td>
                      <td className="py-3 text-right text-foreground">{player.avgADR}</td>
                      <td className={`py-3 text-right font-medium ${player.fkfd >= 0 ? 'text-chart-4' : 'text-destructive'}`}>
                        {player.fkfd >= 0 ? '+' : ''}{player.fkfd}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
