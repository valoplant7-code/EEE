'use client'

import { Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import type { ScrimNote } from '@/lib/types'

interface NoteCardProps {
  note: ScrimNote
  onDelete: (id: string) => void
}

export function NoteCard({ note, onDelete }: NoteCardProps) {
  return (
    <div className="flex items-start gap-3 rounded-lg border border-primary/40 bg-card p-4">
      <div className="flex h-10 w-12 shrink-0 items-center justify-center rounded bg-primary/20 text-sm font-bold text-primary">
        R{note.round_number}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span>{note.our_score}-{note.their_score}</span>
          <span className="font-medium text-foreground">{note.content}</span>
        </div>
        <div className="mt-1 text-xs text-muted-foreground">
          {note.author} @ {new Date(note.created_at).toLocaleTimeString('en-US', { 
            hour: 'numeric', 
            minute: '2-digit',
            hour12: true,
            timeZoneName: 'short'
          })}
        </div>
      </div>
      <Button
        variant="ghost"
        size="icon"
        className="shrink-0 text-muted-foreground hover:text-destructive"
        onClick={() => onDelete(note.id)}
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  )
}
