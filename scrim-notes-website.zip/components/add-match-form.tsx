'use client'

import React from "react"

import { useState } from 'react'
import { Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { VALORANT_MAPS, VALORANT_AGENTS } from '@/lib/types'

interface PlayerStatInput {
  player_name: string
  agent: string
  kills: number
  deaths: number
  assists: number
  acs: number
  adr: number
  first_kills: number
  first_deaths: number
}

interface AddMatchFormProps {
  onSubmit: (match: {
    date: string
    opponent: string
    map: string
    our_score: number
    their_score: number
    vod_url?: string
    notes?: string
    player_stats: PlayerStatInput[]
  }) => void
}

const emptyPlayerStat: PlayerStatInput = {
  player_name: '',
  agent: '',
  kills: 0,
  deaths: 0,
  assists: 0,
  acs: 0,
  adr: 0,
  first_kills: 0,
  first_deaths: 0
}

export function AddMatchForm({ onSubmit }: AddMatchFormProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [date, setDate] = useState(new Date().toISOString().split('T')[0])
  const [opponent, setOpponent] = useState('')
  const [map, setMap] = useState('')
  const [ourScore, setOurScore] = useState('')
  const [theirScore, setTheirScore] = useState('')
  const [vodUrl, setVodUrl] = useState('')
  const [notes, setNotes] = useState('')
  const [playerStats, setPlayerStats] = useState<PlayerStatInput[]>([
    { ...emptyPlayerStat },
    { ...emptyPlayerStat },
    { ...emptyPlayerStat },
    { ...emptyPlayerStat },
    { ...emptyPlayerStat }
  ])

  const updatePlayerStat = (index: number, field: keyof PlayerStatInput, value: string | number) => {
    setPlayerStats((prev) => {
      const updated = [...prev]
      updated[index] = { ...updated[index], [field]: value }
      return updated
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!date || !opponent || !map || !ourScore || !theirScore) return

    const validStats = playerStats.filter(s => s.player_name && s.agent)

    onSubmit({
      date,
      opponent,
      map,
      our_score: parseInt(ourScore),
      their_score: parseInt(theirScore),
      vod_url: vodUrl || undefined,
      notes: notes || undefined,
      player_stats: validStats
    })

    // Reset form
    setDate(new Date().toISOString().split('T')[0])
    setOpponent('')
    setMap('')
    setOurScore('')
    setTheirScore('')
    setVodUrl('')
    setNotes('')
    setPlayerStats([
      { ...emptyPlayerStat },
      { ...emptyPlayerStat },
      { ...emptyPlayerStat },
      { ...emptyPlayerStat },
      { ...emptyPlayerStat }
    ])
    setIsOpen(false)
  }

  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="flex items-center justify-between">
        <button
          className="flex items-center gap-2 text-foreground"
          onClick={() => setIsOpen(!isOpen)}
        >
          <Plus className="h-4 w-4" />
          <span className="font-medium">Add Match Data</span>
        </button>
        {!isOpen && (
          <Button onClick={() => setIsOpen(true)} className="bg-primary text-primary-foreground hover:bg-primary/90">
            New Match
          </Button>
        )}
      </div>

      {isOpen && (
        <form onSubmit={handleSubmit} className="mt-4 space-y-6">
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="bg-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="opponent">Opponent</Label>
              <Input
                id="opponent"
                value={opponent}
                onChange={(e) => setOpponent(e.target.value)}
                placeholder="Team name"
                className="bg-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="map">Map</Label>
              <Select value={map} onValueChange={setMap}>
                <SelectTrigger className="bg-input">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  {VALORANT_MAPS.map((m) => (
                    <SelectItem key={m} value={m}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ourScore">Our Score</Label>
              <Input
                id="ourScore"
                type="number"
                min="0"
                max="13"
                value={ourScore}
                onChange={(e) => setOurScore(e.target.value)}
                className="bg-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="theirScore">Their Score</Label>
              <Input
                id="theirScore"
                type="number"
                min="0"
                max="13"
                value={theirScore}
                onChange={(e) => setTheirScore(e.target.value)}
                className="bg-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="vodUrl">VOD URL</Label>
              <Input
                id="vodUrl"
                value={vodUrl}
                onChange={(e) => setVodUrl(e.target.value)}
                placeholder="https://..."
                className="bg-input"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Match Notes</Label>
            <Input
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="General observations..."
              className="bg-input"
            />
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-foreground">Player Stats</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-left text-muted-foreground">
                    <th className="pb-2 pr-2">Player</th>
                    <th className="pb-2 pr-2">Agent</th>
                    <th className="pb-2 pr-2">K</th>
                    <th className="pb-2 pr-2">D</th>
                    <th className="pb-2 pr-2">A</th>
                    <th className="pb-2 pr-2">ACS</th>
                    <th className="pb-2 pr-2">ADR</th>
                    <th className="pb-2 pr-2">FK</th>
                    <th className="pb-2">FD</th>
                  </tr>
                </thead>
                <tbody>
                  {playerStats.map((stat, i) => (
                    <tr key={i} className="border-b border-border/50">
                      <td className="py-2 pr-2">
                        <Input
                          value={stat.player_name}
                          onChange={(e) => updatePlayerStat(i, 'player_name', e.target.value)}
                          placeholder={`Player ${i + 1}`}
                          className="h-8 bg-input"
                        />
                      </td>
                      <td className="py-2 pr-2">
                        <Select value={stat.agent} onValueChange={(v) => updatePlayerStat(i, 'agent', v)}>
                          <SelectTrigger className="h-8 w-24 bg-input">
                            <SelectValue placeholder="Agent" />
                          </SelectTrigger>
                          <SelectContent>
                            {VALORANT_AGENTS.map((a) => (
                              <SelectItem key={a} value={a}>{a}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="py-2 pr-2">
                        <Input
                          type="number"
                          min="0"
                          value={stat.kills || ''}
                          onChange={(e) => updatePlayerStat(i, 'kills', parseInt(e.target.value) || 0)}
                          className="h-8 w-14 bg-input"
                        />
                      </td>
                      <td className="py-2 pr-2">
                        <Input
                          type="number"
                          min="0"
                          value={stat.deaths || ''}
                          onChange={(e) => updatePlayerStat(i, 'deaths', parseInt(e.target.value) || 0)}
                          className="h-8 w-14 bg-input"
                        />
                      </td>
                      <td className="py-2 pr-2">
                        <Input
                          type="number"
                          min="0"
                          value={stat.assists || ''}
                          onChange={(e) => updatePlayerStat(i, 'assists', parseInt(e.target.value) || 0)}
                          className="h-8 w-14 bg-input"
                        />
                      </td>
                      <td className="py-2 pr-2">
                        <Input
                          type="number"
                          min="0"
                          value={stat.acs || ''}
                          onChange={(e) => updatePlayerStat(i, 'acs', parseInt(e.target.value) || 0)}
                          className="h-8 w-16 bg-input"
                        />
                      </td>
                      <td className="py-2 pr-2">
                        <Input
                          type="number"
                          min="0"
                          value={stat.adr || ''}
                          onChange={(e) => updatePlayerStat(i, 'adr', parseInt(e.target.value) || 0)}
                          className="h-8 w-16 bg-input"
                        />
                      </td>
                      <td className="py-2 pr-2">
                        <Input
                          type="number"
                          min="0"
                          value={stat.first_kills || ''}
                          onChange={(e) => updatePlayerStat(i, 'first_kills', parseInt(e.target.value) || 0)}
                          className="h-8 w-14 bg-input"
                        />
                      </td>
                      <td className="py-2">
                        <Input
                          type="number"
                          min="0"
                          value={stat.first_deaths || ''}
                          onChange={(e) => updatePlayerStat(i, 'first_deaths', parseInt(e.target.value) || 0)}
                          className="h-8 w-14 bg-input"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" className="bg-primary text-primary-foreground">
              Save Match
            </Button>
          </div>
        </form>
      )}
    </div>
  )
}
