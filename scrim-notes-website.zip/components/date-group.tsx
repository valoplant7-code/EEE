'use client'

import { useState } from 'react'
import { ChevronDown, ChevronRight, Calendar, Video, FileText, Link2, Copy } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { NoteCard } from './note-card'
import type { ScrimNote } from '@/lib/types'

interface DateGroupProps {
  date: string
  notes: ScrimNote[]
  onDeleteNote: (id: string) => void
}

export function DateGroup({ date, notes, onDeleteNote }: DateGroupProps) {
  const [isExpanded, setIsExpanded] = useState(true)
  
  const formattedDate = new Date(date).toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  })

  const timestampCount = notes.filter(n => n.timestamp).length

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <button
          className="flex items-center gap-2 text-left"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          {isExpanded ? (
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          ) : (
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          )}
          <Calendar className="h-4 w-4 text-muted-foreground" />
          <span className="font-semibold text-foreground">{formattedDate}</span>
          <span className="text-sm text-muted-foreground">({notes.length} notes)</span>
        </button>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
            <Video className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
            <FileText className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
            <Link2 className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
            <Copy className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {isExpanded && (
        <div className="space-y-2 pl-6">
          {timestampCount > 0 && (
            <div className="flex items-center gap-2">
              <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
                Regenerate Timestamps
              </Button>
              <span className="text-sm text-muted-foreground">{timestampCount} timestamps saved</span>
            </div>
          )}
          <div className="space-y-2">
            {notes.map((note) => (
              <NoteCard key={note.id} note={note} onDelete={onDeleteNote} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
