'use client'

import { useState, useRef } from 'react'
import { Upload, FileSpreadsheet, BarChart3, Target, Crosshair, Bomb, TrendingUp, MapPin } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import * as XLSX from 'xlsx'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts'

interface MapStats {
  map: string
  played: number
  winPercent: number
  losePercent: number
  tiePercent: number
  fkPercent: number
  fkWinPercent: number
  aFkWinPercent: number
  dFkWinPercent: number
  fdPercent: number
  fdWinPercent: number
  aFdWinPercent: number
  dFdWinPercent: number
  ecoPercent: number
  ecoWinPercent: number
  aEcoPercent: number
  aEcoWinPercent: number
}

interface OverallStats {
  totalMaps: number
  totalWins: number
  totalLosses: number
  totalTies: number
  avgFkPercent: number
  avgFkWinPercent: number
  avgFdPercent: number
  avgPlantPercent: number
  avgRetakePercent: number
}

export function StatsDashboard() {
  const [mapStats, setMapStats] = useState<MapStats[]>([])
  const [overallStats, setOverallStats] = useState<OverallStats | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  function parsePercent(val: unknown): number {
    if (val === undefined || val === null || val === '' || val === '#DIV/0!') return 0
    if (typeof val === 'number') {
      return val > 1 ? val : val * 100
    }
    const str = String(val).replace('%', '').replace('#DIV/0!', '0').trim()
    const num = parseFloat(str)
    return isNaN(num) ? 0 : (num > 1 ? num : num * 100)
  }

  async function handleFileUpload(file: File) {
    if (!file.name.match(/\.(xlsx|xls)$/i)) {
      setError('Please upload an Excel file (.xlsx or .xls)')
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const data = await file.arrayBuffer()
      const workbook = XLSX.read(data, { type: 'array' })
      
      // Look for Summary sheet or first sheet
      const summarySheet = workbook.Sheets['Summary'] || workbook.Sheets[workbook.SheetNames[0]]
      
      if (!summarySheet) {
        throw new Error('Could not find Summary sheet')
      }

      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(summarySheet, { header: 1 }) as unknown[][]
      
      // Find header row with map stats columns
      let headerRowIdx = -1
      let colIndex: Record<string, number> = {}
      
      for (let i = 0; i < Math.min(rows.length, 10); i++) {
        const row = rows[i] as string[]
        if (!row) continue
        
        // Look for columns like "Played", "Win%", "FK%", etc.
        const hasStatsColumns = row.some(cell => {
          const val = String(cell || '').toLowerCase()
          return val.includes('played') || val.includes('win%') || val.includes('fk%')
        })
        
        if (hasStatsColumns) {
          headerRowIdx = i
          row.forEach((h, idx) => {
            const key = String(h || '').toLowerCase().replace(/\s+/g, '').replace('%', 'percent')
            if (key) colIndex[key] = idx
          })
          break
        }
      }

      if (headerRowIdx < 0) {
        throw new Error('Could not find stats header row')
      }

      // Parse map stats
      const stats: MapStats[] = []
      const mapNames = ['abyss', 'bind', 'breeze', 'corrode', 'haven', 'pearl', 'split', 'ascent', 'fracture', 'icebox', 'lotus', 'sunset']
      
      for (let rowIdx = headerRowIdx + 1; rowIdx < rows.length; rowIdx++) {
        const row = rows[rowIdx] as (string | number)[]
        if (!row || row.length === 0) continue
        
        // First column is usually the map name
        const mapName = String(row[0] || '').toLowerCase().trim()
        if (!mapName || !mapNames.some(m => mapName.includes(m))) continue

        stats.push({
          map: mapName.charAt(0).toUpperCase() + mapName.slice(1),
          played: Number(row[colIndex['played']] || 0),
          winPercent: parsePercent(row[colIndex['winpercent'] || colIndex['win']]),
          losePercent: parsePercent(row[colIndex['losepercent'] || colIndex['lose']]),
          tiePercent: parsePercent(row[colIndex['tiepercent'] || colIndex['tie']]),
          fkPercent: parsePercent(row[colIndex['fkpercent'] || colIndex['fk']]),
          fkWinPercent: parsePercent(row[colIndex['fkwpercent'] || colIndex['fkw']]),
          aFkWinPercent: parsePercent(row[colIndex['afkwpercent'] || colIndex['afkw']]),
          dFkWinPercent: parsePercent(row[colIndex['dfkwpercent'] || colIndex['dfkw']]),
          fdPercent: parsePercent(row[colIndex['fdpercent'] || colIndex['fd']]),
          fdWinPercent: parsePercent(row[colIndex['fdwpercent'] || colIndex['fdw']]),
          aFdWinPercent: parsePercent(row[colIndex['afdwpercent'] || colIndex['afdw']]),
          dFdWinPercent: parsePercent(row[colIndex['dfdwpercent'] || colIndex['dfdw']]),
          ecoPercent: parsePercent(row[colIndex['ecopercent'] || colIndex['eco']]),
          ecoWinPercent: parsePercent(row[colIndex['ecowpercent'] || colIndex['ecow']]),
          aEcoPercent: parsePercent(row[colIndex['a.ecopercent'] || colIndex['aeco']]),
          aEcoWinPercent: parsePercent(row[colIndex['a.ecowpercent'] || colIndex['aecow']])
        })
      }

      if (stats.length === 0) {
        throw new Error('No map data found in the spreadsheet')
      }

      // Calculate overall stats
      const playedMaps = stats.filter(s => s.played > 0)
      const totalPlayed = playedMaps.reduce((acc, s) => acc + s.played, 0)
      
      const overall: OverallStats = {
        totalMaps: totalPlayed,
        totalWins: Math.round(playedMaps.reduce((acc, s) => acc + (s.played * s.winPercent / 100), 0)),
        totalLosses: Math.round(playedMaps.reduce((acc, s) => acc + (s.played * s.losePercent / 100), 0)),
        totalTies: Math.round(playedMaps.reduce((acc, s) => acc + (s.played * s.tiePercent / 100), 0)),
        avgFkPercent: playedMaps.reduce((acc, s) => acc + s.fkPercent, 0) / playedMaps.length || 0,
        avgFkWinPercent: playedMaps.reduce((acc, s) => acc + s.fkWinPercent, 0) / playedMaps.length || 0,
        avgFdPercent: playedMaps.reduce((acc, s) => acc + s.fdPercent, 0) / playedMaps.length || 0,
        avgPlantPercent: 0,
        avgRetakePercent: 0
      }

      setMapStats(stats)
      setOverallStats(overall)
    } catch (err) {
      console.error('Error parsing stats:', err)
      setError(err instanceof Error ? err.message : 'Failed to parse spreadsheet')
    } finally {
      setIsLoading(false)
    }
  }

  const mapWinRateData = mapStats
    .filter(s => s.played > 0)
    .map(s => ({
      map: s.map,
      'Win %': s.winPercent,
      'Loss %': s.losePercent,
      played: s.played
    }))
    .sort((a, b) => b['Win %'] - a['Win %'])

  const fkFdData = mapStats
    .filter(s => s.played > 0)
    .map(s => ({
      map: s.map,
      'FK %': s.fkPercent,
      'FD %': s.fdPercent,
      'FK Win %': s.fkWinPercent
    }))

  const radarData = mapStats
    .filter(s => s.played > 0 && s.played >= 2)
    .slice(0, 6)
    .map(s => ({
      map: s.map,
      'Win Rate': s.winPercent,
      'FK Rate': s.fkPercent,
      'FK Win': s.fkWinPercent,
      'Eco Win': s.ecoWinPercent || 50
    }))

  return (
    <div className="space-y-6">
      {/* Upload Section */}
      {mapStats.length === 0 && (
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <FileSpreadsheet className="h-5 w-5 text-primary" />
              Upload Scrim Tracker Spreadsheet
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div
              className="flex flex-col items-center justify-center gap-4 rounded-lg border-2 border-dashed border-border p-12 transition-colors hover:border-primary/50"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault()
                const files = e.dataTransfer.files
                if (files.length > 0) handleFileUpload(files[0])
              }}
            >
              <Upload className="h-12 w-12 text-muted-foreground" />
              <div className="text-center">
                <p className="text-foreground">
                  Drag and drop your GE Scrim Tracker spreadsheet here
                </p>
                <p className="mt-1 text-sm text-muted-foreground">
                  or click to browse (.xlsx, .xls)
                </p>
              </div>
              <Button
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                disabled={isLoading}
                className="bg-transparent"
              >
                {isLoading ? 'Processing...' : 'Select File'}
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={(e) => {
                  const files = e.target.files
                  if (files && files.length > 0) handleFileUpload(files[0])
                }}
              />
            </div>
            {error && (
              <p className="mt-4 text-center text-sm text-destructive">{error}</p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Stats Dashboard */}
      {overallStats && (
        <>
          {/* Overall Stats Cards */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Card className="border-border bg-card">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-primary/20 p-3">
                    <BarChart3 className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Maps Played</p>
                    <p className="text-2xl font-bold text-foreground">{overallStats.totalMaps}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-green-500/20 p-3">
                    <TrendingUp className="h-6 w-6 text-green-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Win Rate</p>
                    <p className="text-2xl font-bold text-green-500">
                      {overallStats.totalMaps > 0
                        ? ((overallStats.totalWins / overallStats.totalMaps) * 100).toFixed(1)
                        : 0}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-red-500/20 p-3">
                    <Crosshair className="h-6 w-6 text-red-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Avg First Kill %</p>
                    <p className="text-2xl font-bold text-foreground">
                      {overallStats.avgFkPercent.toFixed(1)}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-blue-500/20 p-3">
                    <Target className="h-6 w-6 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">FK Win Rate</p>
                    <p className="text-2xl font-bold text-foreground">
                      {overallStats.avgFkWinPercent.toFixed(1)}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Map Win Rate Chart */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-card-foreground">
                <MapPin className="h-5 w-5 text-primary" />
                Win Rate by Map
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={mapWinRateData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis type="number" domain={[0, 100]} tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                    <YAxis 
                      type="category" 
                      dataKey="map" 
                      width={80}
                      tick={{ fill: 'hsl(var(--foreground))' }}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                        color: 'hsl(var(--foreground))'
                      }}
                      formatter={(value: number, name: string) => [`${value.toFixed(1)}%`, name]}
                      labelFormatter={(label) => {
                        const map = mapWinRateData.find(m => m.map === label)
                        return `${label} (${map?.played || 0} games)`
                      }}
                    />
                    <Bar dataKey="Win %" radius={[0, 4, 4, 0]}>
                      {mapWinRateData.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={entry['Win %'] >= 50 ? 'hsl(142, 76%, 36%)' : 'hsl(0, 84%, 60%)'} 
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* FK/FD Stats */}
          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-card-foreground">
                  <Crosshair className="h-5 w-5 text-primary" />
                  First Kill / First Death by Map
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart 
                      data={fkFdData} 
                      barCategoryGap="20%"
                      barGap={2}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                      <XAxis 
                        dataKey="map" 
                        tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} 
                        axisLine={{ stroke: 'hsl(var(--border))' }}
                        tickLine={false}
                      />
                      <YAxis 
                        domain={[0, 100]} 
                        tick={{ fill: 'hsl(var(--muted-foreground))' }} 
                        axisLine={false}
                        tickLine={false}
                        tickFormatter={(value) => `${value}%`}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'hsl(var(--card))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                          color: 'hsl(var(--foreground))'
                        }}
                        formatter={(value: number, name: string) => [`${value.toFixed(1)}%`, name]}
                        cursor={{ fill: 'hsl(var(--muted))', opacity: 0.3 }}
                      />
                      <Legend 
                        wrapperStyle={{ paddingTop: '10px' }}
                        formatter={(value) => <span style={{ color: 'hsl(var(--foreground))' }}>{value}</span>}
                      />
                      <Bar 
                        dataKey="FK %" 
                        name="First Kill %" 
                        fill="#22c55e" 
                        radius={[4, 4, 0, 0]} 
                        maxBarSize={40}
                      />
                      <Bar 
                        dataKey="FD %" 
                        name="First Death %" 
                        fill="#ef4444" 
                        radius={[4, 4, 0, 0]} 
                        maxBarSize={40}
                      />
                      <Bar 
                        dataKey="FK Win %" 
                        name="FK Round Win %" 
                        fill="#3b82f6" 
                        radius={[4, 4, 0, 0]} 
                        maxBarSize={40}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Performance Summary */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-card-foreground">
                  <Target className="h-5 w-5 text-primary" />
                  Key Performance Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {overallStats && (
                    <>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Win Rate</span>
                          <span className={`font-medium ${overallStats.winRate >= 50 ? 'text-green-500' : 'text-red-500'}`}>
                            {overallStats.winRate.toFixed(1)}%
                          </span>
                        </div>
                        <div className="h-3 w-full overflow-hidden rounded-full bg-secondary">
                          <div 
                            className={`h-full rounded-full transition-all ${overallStats.winRate >= 50 ? 'bg-green-500' : 'bg-red-500'}`}
                            style={{ width: `${Math.min(overallStats.winRate, 100)}%` }}
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">First Kill %</span>
                          <span className="font-medium text-blue-500">{overallStats.fkPercent.toFixed(1)}%</span>
                        </div>
                        <div className="h-3 w-full overflow-hidden rounded-full bg-secondary">
                          <div 
                            className="h-full rounded-full bg-blue-500 transition-all"
                            style={{ width: `${Math.min(overallStats.fkPercent, 100)}%` }}
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">FK Round Win %</span>
                          <span className={`font-medium ${overallStats.fkWinPercent >= 70 ? 'text-green-500' : 'text-amber-500'}`}>
                            {overallStats.fkWinPercent.toFixed(1)}%
                          </span>
                        </div>
                        <div className="h-3 w-full overflow-hidden rounded-full bg-secondary">
                          <div 
                            className={`h-full rounded-full transition-all ${overallStats.fkWinPercent >= 70 ? 'bg-green-500' : 'bg-amber-500'}`}
                            style={{ width: `${Math.min(overallStats.fkWinPercent, 100)}%` }}
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">First Death %</span>
                          <span className={`font-medium ${overallStats.fdPercent <= 20 ? 'text-green-500' : 'text-red-500'}`}>
                            {overallStats.fdPercent.toFixed(1)}%
                          </span>
                        </div>
                        <div className="h-3 w-full overflow-hidden rounded-full bg-secondary">
                          <div 
                            className={`h-full rounded-full transition-all ${overallStats.fdPercent <= 20 ? 'bg-green-500' : 'bg-red-500'}`}
                            style={{ width: `${Math.min(overallStats.fdPercent, 100)}%` }}
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Eco Round Win %</span>
                          <span className="font-medium text-purple-500">{overallStats.ecoWinPercent.toFixed(1)}%</span>
                        </div>
                        <div className="h-3 w-full overflow-hidden rounded-full bg-secondary">
                          <div 
                            className="h-full rounded-full bg-purple-500 transition-all"
                            style={{ width: `${Math.min(overallStats.ecoWinPercent, 100)}%` }}
                          />
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Map Stats Table */}
          <Card className="border-border bg-card">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-card-foreground">Detailed Map Statistics</CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setMapStats([])
                  setOverallStats(null)
                }}
                className="bg-transparent"
              >
                Upload New Data
              </Button>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="py-3 text-left font-medium text-muted-foreground">Map</th>
                      <th className="py-3 text-center font-medium text-muted-foreground">Played</th>
                      <th className="py-3 text-center font-medium text-muted-foreground">Win %</th>
                      <th className="py-3 text-center font-medium text-muted-foreground">FK %</th>
                      <th className="py-3 text-center font-medium text-muted-foreground">FK W%</th>
                      <th className="py-3 text-center font-medium text-muted-foreground">FD %</th>
                      <th className="py-3 text-center font-medium text-muted-foreground">FD W%</th>
                      <th className="py-3 text-center font-medium text-muted-foreground">Eco W%</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mapStats.filter(s => s.played > 0).map((stat) => (
                      <tr key={stat.map} className="border-b border-border/50">
                        <td className="py-3 font-medium text-foreground">{stat.map}</td>
                        <td className="py-3 text-center text-foreground">{stat.played}</td>
                        <td className={`py-3 text-center font-medium ${stat.winPercent >= 50 ? 'text-green-500' : 'text-red-500'}`}>
                          {stat.winPercent.toFixed(1)}%
                        </td>
                        <td className="py-3 text-center text-foreground">{stat.fkPercent.toFixed(1)}%</td>
                        <td className={`py-3 text-center ${stat.fkWinPercent >= 70 ? 'text-green-500' : 'text-foreground'}`}>
                          {stat.fkWinPercent.toFixed(1)}%
                        </td>
                        <td className="py-3 text-center text-foreground">{stat.fdPercent.toFixed(1)}%</td>
                        <td className={`py-3 text-center ${stat.fdWinPercent >= 30 ? 'text-foreground' : 'text-red-500'}`}>
                          {stat.fdWinPercent.toFixed(1)}%
                        </td>
                        <td className="py-3 text-center text-foreground">{stat.ecoWinPercent.toFixed(1)}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Areas to Work On */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-card-foreground">
                <Bomb className="h-5 w-5 text-primary" />
                Areas to Improve
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {mapStats
                  .filter(s => s.played >= 2)
                  .sort((a, b) => a.winPercent - b.winPercent)
                  .slice(0, 3)
                  .map(stat => (
                    <div key={stat.map} className="rounded-lg border border-red-500/30 bg-red-500/10 p-4">
                      <h4 className="font-semibold text-foreground">{stat.map}</h4>
                      <p className="mt-1 text-sm text-red-400">
                        {stat.winPercent.toFixed(0)}% win rate ({stat.played} games)
                      </p>
                      <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
                        {stat.fkPercent < 50 && <li>- Low first kill rate ({stat.fkPercent.toFixed(0)}%)</li>}
                        {stat.fdPercent > 50 && <li>- High first death rate ({stat.fdPercent.toFixed(0)}%)</li>}
                        {stat.ecoWinPercent < 30 && <li>- Struggling on eco rounds</li>}
                      </ul>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}
