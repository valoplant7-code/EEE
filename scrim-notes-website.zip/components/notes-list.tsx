'use client'

import { MessageSquare } from 'lucide-react'
import { DateGroup } from './date-group'
import type { ScrimNote } from '@/lib/types'

interface NotesListProps {
  notes: ScrimNote[]
  onDeleteNote: (id: string) => void
}

export function NotesList({ notes, onDeleteNote }: NotesListProps) {
  // Group notes by date
  const groupedNotes = notes.reduce((acc, note) => {
    const date = new Date(note.created_at).toISOString().split('T')[0]
    if (!acc[date]) {
      acc[date] = []
    }
    acc[date].push(note)
    return acc
  }, {} as Record<string, ScrimNote[]>)

  // Sort dates in descending order
  const sortedDates = Object.keys(groupedNotes).sort((a, b) => 
    new Date(b).getTime() - new Date(a).getTime()
  )

  const totalNotes = notes.length
  const uniqueDays = sortedDates.length
  const notesWithTimestamp = notes.filter(n => n.timestamp).length
  const notesWithVod = notes.filter(n => n.vod_url).length

  return (
    <div className="rounded-lg border border-border bg-card p-6">
      <div className="mb-4 flex items-center gap-2">
        <MessageSquare className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-semibold">Saved Notes</h2>
        <span className="text-sm text-muted-foreground">
          ({totalNotes} total across {uniqueDays} days)
        </span>
      </div>

      <div className="mb-6 flex flex-wrap gap-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-sm border border-chart-4 bg-chart-4/20" />
          <span className="text-muted-foreground">Timestamp available</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-sm border border-muted-foreground" />
          <span className="text-muted-foreground">No timestamp</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-sm bg-chart-5" />
          <span className="text-muted-foreground">VOD</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-sm bg-chart-2" />
          <span className="text-muted-foreground">Data</span>
        </div>
      </div>

      {notes.length === 0 ? (
        <p className="py-8 text-center text-muted-foreground">
          No notes yet. Add your first note above!
        </p>
      ) : (
        <div className="space-y-6">
          {sortedDates.map((date) => (
            <DateGroup
              key={date}
              date={date}
              notes={groupedNotes[date]}
              onDeleteNote={onDeleteNote}
            />
          ))}
        </div>
      )}
    </div>
  )
}
