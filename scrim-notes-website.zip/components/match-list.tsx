'use client'

import { Trash2, ExternalLink } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import type { ScrimMatch } from '@/lib/types'

interface MatchListProps {
  matches: ScrimMatch[]
  onDelete: (id: string) => void
}

export function MatchList({ matches, onDelete }: MatchListProps) {
  if (matches.length === 0) {
    return (
      <Card className="border-border bg-card">
        <CardContent className="py-8 text-center text-muted-foreground">
          No matches recorded yet. Add your first match above!
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <CardTitle className="text-lg">Recent Matches</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {matches.map((match) => (
            <div
              key={match.id}
              className={`flex items-center gap-4 rounded-lg border p-4 ${
                match.result === 'win' 
                  ? 'border-chart-4/40 bg-chart-4/10' 
                  : match.result === 'loss'
                  ? 'border-destructive/40 bg-destructive/10'
                  : 'border-border bg-secondary/50'
              }`}
            >
              <div className={`flex h-10 w-10 items-center justify-center rounded text-sm font-bold ${
                match.result === 'win' 
                  ? 'bg-chart-4/20 text-chart-4' 
                  : match.result === 'loss'
                  ? 'bg-destructive/20 text-destructive'
                  : 'bg-muted text-muted-foreground'
              }`}>
                {match.result === 'win' ? 'W' : match.result === 'loss' ? 'L' : 'D'}
              </div>
              
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-foreground">vs {match.opponent_name}</span>
                  <span className="text-sm text-muted-foreground">on {match.map}</span>
                </div>
                <div className="text-sm text-muted-foreground">
                  {new Date(match.match_date).toLocaleDateString('en-US', {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric'
                  })}
                  {match.notes && <span className="ml-2">- {match.notes}</span>}
                </div>
              </div>

              <div className="text-xl font-bold text-foreground">
                {match.our_score} - {match.enemy_score}
              </div>

              <div className="flex items-center gap-1">
                {match.vod_url && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-muted-foreground hover:text-primary"
                    asChild
                  >
                    <a href={match.vod_url} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                  onClick={() => onDelete(match.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
