'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { BarChart3, TrendingUp, TrendingDown, Target, Crosshair, RefreshCw } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts'

interface DataFile {
  id: string
  file_name: string
  date_start: string
  date_end?: string
  maps: string[]
  teams: string[]
  match_count: number
  stats: Record<string, unknown>
}

interface MapStats {
  map: string
  played: number
  wins: number
  losses: number
  winRate: number
}

export function MetricsPage() {
  const [files, setFiles] = useState<DataFile[]>([])
  const [loading, setLoading] = useState(true)
  const [dateRange, setDateRange] = useState('all')
  const supabase = createClient()

  useEffect(() => {
    fetchData()
  }, [dateRange])

  async function fetchData() {
    setLoading(true)
    let query = supabase.from('scrim_data_files').select('*').order('date_start', { ascending: false })

    if (dateRange === '7d') {
      const date = new Date()
      date.setDate(date.getDate() - 7)
      query = query.gte('date_start', date.toISOString().split('T')[0])
    } else if (dateRange === '30d') {
      const date = new Date()
      date.setDate(date.getDate() - 30)
      query = query.gte('date_start', date.toISOString().split('T')[0])
    }

    const { data, error } = await query

    if (error) {
      console.error('Error fetching data:', error)
    } else {
      setFiles(data || [])
    }
    setLoading(false)
  }

  // Calculate aggregate stats
  const totalMatches = files.reduce((acc, f) => acc + f.match_count, 0)
  const allMaps = files.flatMap(f => f.maps)
  const uniqueMaps = [...new Set(allMaps)]
  const allTeams = files.flatMap(f => f.teams)
  const uniqueTeams = [...new Set(allTeams)]

  // Map frequency data
  const mapFrequency = uniqueMaps.map(map => ({
    map,
    count: allMaps.filter(m => m === map).length
  })).sort((a, b) => b.count - a.count)

  // Team frequency data  
  const teamFrequency = uniqueTeams.map(team => ({
    team,
    count: allTeams.filter(t => t === team).length
  })).sort((a, b) => b.count - a.count).slice(0, 10)

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Metrics Dashboard</h1>
          <p className="text-muted-foreground">
            Overview of your scrim performance and statistics
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Time</SelectItem>
              <SelectItem value="30d">Last 30 Days</SelectItem>
              <SelectItem value="7d">Last 7 Days</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon" onClick={fetchData} disabled={loading}>
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="border-border bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-primary/10 p-2">
                <BarChart3 className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Scrims</p>
                <p className="text-2xl font-bold text-foreground">{files.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-emerald-500/10 p-2">
                <Target className="h-5 w-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Matches</p>
                <p className="text-2xl font-bold text-foreground">{totalMatches}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-blue-500/10 p-2">
                <Crosshair className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Maps Played</p>
                <p className="text-2xl font-bold text-foreground">{uniqueMaps.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-purple-500/10 p-2">
                <TrendingUp className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Teams Faced</p>
                <p className="text-2xl font-bold text-foreground">{uniqueTeams.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-card-foreground">Map Frequency</CardTitle>
          </CardHeader>
          <CardContent>
            {mapFrequency.length > 0 ? (
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={mapFrequency} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" horizontal={false} />
                    <XAxis type="number" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                    <YAxis 
                      type="category" 
                      dataKey="map" 
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                      width={70}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                        color: 'hsl(var(--foreground))'
                      }}
                    />
                    <Bar dataKey="count" fill="#22c55e" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="flex h-72 items-center justify-center text-muted-foreground">
                No data available
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-card-foreground">Teams Faced</CardTitle>
          </CardHeader>
          <CardContent>
            {teamFrequency.length > 0 ? (
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={teamFrequency} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" horizontal={false} />
                    <XAxis type="number" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                    <YAxis 
                      type="category" 
                      dataKey="team" 
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                      width={60}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                        color: 'hsl(var(--foreground))'
                      }}
                    />
                    <Bar dataKey="count" fill="#a855f7" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="flex h-72 items-center justify-center text-muted-foreground">
                No data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="mt-6 border-border bg-card">
        <CardHeader>
          <CardTitle className="text-card-foreground">Recent Scrims</CardTitle>
        </CardHeader>
        <CardContent>
          {files.length > 0 ? (
            <div className="space-y-3">
              {files.slice(0, 5).map(file => (
                <div key={file.id} className="flex items-center justify-between rounded-lg border border-border p-3">
                  <div className="flex items-center gap-4">
                    <span className="font-medium text-foreground">
                      {new Date(file.date_start).toLocaleDateString('en-US', {
                        month: 'short', day: 'numeric', year: 'numeric'
                      })}
                    </span>
                    <div className="flex gap-1">
                      {file.maps.slice(0, 3).map(map => (
                        <span key={map} className="rounded bg-emerald-500/20 px-2 py-0.5 text-xs text-emerald-400">
                          {map}
                        </span>
                      ))}
                    </div>
                    <div className="flex gap-1">
                      {file.teams.slice(0, 2).map(team => (
                        <span key={team} className="rounded bg-purple-500/20 px-2 py-0.5 text-xs text-purple-400">
                          {team}
                        </span>
                      ))}
                    </div>
                  </div>
                  <span className="text-sm text-muted-foreground">{file.match_count} matches</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center text-muted-foreground">
              No scrims recorded yet
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
