'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Lightbulb, TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Target } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface DataFile {
  id: string
  date_start: string
  date_end?: string
  maps: string[]
  teams: string[]
  match_count: number
  stats: Record<string, unknown>
}

interface Insight {
  type: 'positive' | 'negative' | 'neutral'
  title: string
  description: string
  metric?: string
}

export function InsightsPage() {
  const [files, setFiles] = useState<DataFile[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    fetchData()
  }, [])

  async function fetchData() {
    setLoading(true)
    const { data, error } = await supabase
      .from('scrim_data_files')
      .select('*')
      .order('date_start', { ascending: false })

    if (error) {
      console.error('Error fetching data:', error)
    } else {
      setFiles(data || [])
    }
    setLoading(false)
  }

  // Generate insights based on data
  function generateInsights(): Insight[] {
    if (files.length === 0) return []

    const insights: Insight[] = []
    const allMaps = files.flatMap(f => f.maps)
    const allTeams = files.flatMap(f => f.teams)
    
    // Map frequency analysis
    const mapCounts = allMaps.reduce((acc, map) => {
      acc[map] = (acc[map] || 0) + 1
      return acc
    }, {} as Record<string, number>)
    
    const sortedMaps = Object.entries(mapCounts).sort((a, b) => b[1] - a[1])
    
    if (sortedMaps.length > 0) {
      const [topMap, topCount] = sortedMaps[0]
      const totalMaps = allMaps.length
      const percentage = ((topCount / totalMaps) * 100).toFixed(0)
      
      insights.push({
        type: 'neutral',
        title: `${topMap} is your most played map`,
        description: `You've played ${topMap} ${topCount} times (${percentage}% of all maps). Consider diversifying your map pool if this is too concentrated.`,
        metric: `${percentage}%`
      })
    }

    // Least played maps
    const valorantMaps = ['Abyss', 'Bind', 'Breeze', 'Haven', 'Pearl', 'Split', 'Corrode']
    const unplayedMaps = valorantMaps.filter(map => !mapCounts[map])
    
    if (unplayedMaps.length > 0) {
      insights.push({
        type: 'negative',
        title: `Missing maps in your pool`,
        description: `You haven't practiced on: ${unplayedMaps.join(', ')}. Consider adding these to your scrim rotation.`,
      })
    }

    // Scrim frequency
    const recentFiles = files.filter(f => {
      const date = new Date(f.date_start)
      const weekAgo = new Date()
      weekAgo.setDate(weekAgo.getDate() - 7)
      return date >= weekAgo
    })

    if (recentFiles.length >= 3) {
      insights.push({
        type: 'positive',
        title: 'Good scrim frequency',
        description: `You've had ${recentFiles.length} scrims in the last 7 days. Consistent practice leads to improvement!`,
        metric: `${recentFiles.length} scrims`
      })
    } else if (recentFiles.length === 0 && files.length > 0) {
      insights.push({
        type: 'negative',
        title: 'No recent scrims',
        description: 'You haven\'t recorded any scrims in the last week. Try to maintain consistent practice.',
      })
    }

    // Team diversity
    const uniqueTeams = [...new Set(allTeams)]
    if (uniqueTeams.length >= 5) {
      insights.push({
        type: 'positive',
        title: 'Good team variety',
        description: `You've faced ${uniqueTeams.length} different teams. Playing against varied opponents helps develop adaptability.`,
        metric: `${uniqueTeams.length} teams`
      })
    }

    // Repeat opponents
    const teamCounts = allTeams.reduce((acc, team) => {
      acc[team] = (acc[team] || 0) + 1
      return acc
    }, {} as Record<string, number>)
    
    const repeatTeams = Object.entries(teamCounts).filter(([_, count]) => count >= 3)
    if (repeatTeams.length > 0) {
      insights.push({
        type: 'neutral',
        title: 'Frequent opponents detected',
        description: `You've faced ${repeatTeams.map(([t, c]) => `${t} (${c}x)`).join(', ')} multiple times. Great for rivalry development but ensure you're also facing new teams.`,
      })
    }

    // Total match volume
    const totalMatches = files.reduce((acc, f) => acc + f.match_count, 0)
    if (totalMatches >= 50) {
      insights.push({
        type: 'positive',
        title: 'Strong practice volume',
        description: `You've played ${totalMatches} total matches. This level of practice should translate to improvement.`,
        metric: `${totalMatches} matches`
      })
    }

    return insights
  }

  const insights = generateInsights()

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Insights</h1>
        <p className="text-muted-foreground">
          AI-generated insights and recommendations based on your scrim data
        </p>
      </div>

      {loading ? (
        <div className="py-12 text-center text-muted-foreground">Loading insights...</div>
      ) : insights.length === 0 ? (
        <Card className="border-border bg-card">
          <CardContent className="py-12 text-center">
            <Lightbulb className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
            <p className="text-lg font-medium text-foreground">No insights yet</p>
            <p className="text-muted-foreground">
              Upload some scrim data to generate personalized insights
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {insights.map((insight, i) => (
            <Card key={i} className="border-border bg-card">
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <div className={`mt-1 rounded-lg p-2 ${
                    insight.type === 'positive' ? 'bg-emerald-500/10' :
                    insight.type === 'negative' ? 'bg-red-500/10' :
                    'bg-blue-500/10'
                  }`}>
                    {insight.type === 'positive' ? (
                      <CheckCircle className="h-5 w-5 text-emerald-500" />
                    ) : insight.type === 'negative' ? (
                      <AlertTriangle className="h-5 w-5 text-red-500" />
                    ) : (
                      <Target className="h-5 w-5 text-blue-500" />
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <h3 className="font-medium text-foreground">{insight.title}</h3>
                      {insight.metric && (
                        <span className={`rounded px-2 py-0.5 text-sm font-medium ${
                          insight.type === 'positive' ? 'bg-emerald-500/20 text-emerald-400' :
                          insight.type === 'negative' ? 'bg-red-500/20 text-red-400' :
                          'bg-blue-500/20 text-blue-400'
                        }`}>
                          {insight.metric}
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{insight.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Recommendations Section */}
      <Card className="mt-6 border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-card-foreground">
            <TrendingUp className="h-5 w-5 text-primary" />
            Areas to Focus On
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start gap-3 rounded-lg border border-border p-3">
              <div className="rounded bg-amber-500/10 p-1.5">
                <Target className="h-4 w-4 text-amber-500" />
              </div>
              <div>
                <p className="font-medium text-foreground">Map Pool Balance</p>
                <p className="text-sm text-muted-foreground">
                  Ensure you're practicing all maps in your competitive pool evenly
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 rounded-lg border border-border p-3">
              <div className="rounded bg-purple-500/10 p-1.5">
                <Lightbulb className="h-4 w-4 text-purple-500" />
              </div>
              <div>
                <p className="font-medium text-foreground">Opponent Variety</p>
                <p className="text-sm text-muted-foreground">
                  Scrim against different playstyles to develop adaptability
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 rounded-lg border border-border p-3">
              <div className="rounded bg-emerald-500/10 p-1.5">
                <TrendingUp className="h-4 w-4 text-emerald-500" />
              </div>
              <div>
                <p className="font-medium text-foreground">Consistent Practice</p>
                <p className="text-sm text-muted-foreground">
                  Aim for at least 3-4 scrims per week to maintain improvement
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
