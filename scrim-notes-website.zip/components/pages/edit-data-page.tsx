'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { FileSpreadsheet, ChevronRight, RefreshCw, Pencil } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface DataFile {
  id: string
  file_name: string
  upload_date: string
  date_start: string
  date_end?: string
  maps: string[]
  teams: string[]
  match_count: number
  stats: Record<string, unknown>
  created_at: string
}

interface GroupedFiles {
  dateLabel: string
  files: DataFile[]
}

export function EditDataPage() {
  const [files, setFiles] = useState<DataFile[]>([])
  const [loading, setLoading] = useState(true)
  const [expandedDates, setExpandedDates] = useState<Set<string>>(new Set())
  const supabase = createClient()

  useEffect(() => {
    fetchFiles()
  }, [])

  async function fetchFiles() {
    setLoading(true)
    const { data, error } = await supabase
      .from('scrim_data_files')
      .select('*')
      .order('date_start', { ascending: false })

    if (error) {
      console.error('Error fetching files:', error)
    } else {
      setFiles(data || [])
      // Auto-expand the first date group
      if (data && data.length > 0) {
        const firstDate = formatDateLabel(data[0])
        setExpandedDates(new Set([firstDate]))
      }
    }
    setLoading(false)
  }

  function formatDateLabel(file: DataFile): string {
    const start = new Date(file.date_start)
    if (file.date_end) {
      const end = new Date(file.date_end)
      if (start.toDateString() === end.toDateString()) {
        return start.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })
      }
      return `${start.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${end.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`
    }
    return start.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })
  }

  function groupFilesByDate(): GroupedFiles[] {
    const groups: Map<string, DataFile[]> = new Map()
    
    files.forEach(file => {
      const label = formatDateLabel(file)
      if (!groups.has(label)) {
        groups.set(label, [])
      }
      groups.get(label)!.push(file)
    })

    return Array.from(groups.entries()).map(([dateLabel, files]) => ({
      dateLabel,
      files
    }))
  }

  function toggleDate(dateLabel: string) {
    setExpandedDates(prev => {
      const next = new Set(prev)
      if (next.has(dateLabel)) {
        next.delete(dateLabel)
      } else {
        next.add(dateLabel)
      }
      return next
    })
  }

  const groupedFiles = groupFilesByDate()

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Edit Data</h1>
        <p className="text-muted-foreground">
          Select an Excel file to view and edit its contents. Changes are synced to storage.
        </p>
      </div>

      <Card className="border-border bg-card">
        <CardContent className="p-4">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5 text-muted-foreground" />
              <span className="font-semibold text-foreground">Data Files</span>
              <span className="text-muted-foreground">({files.length})</span>
            </div>
            <Button variant="ghost" size="icon" onClick={fetchFiles} disabled={loading}>
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </Button>
          </div>

          {loading ? (
            <div className="py-8 text-center text-muted-foreground">Loading...</div>
          ) : files.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">
              No data files uploaded yet. Go to Upload Data to add files.
            </div>
          ) : (
            <div className="space-y-2">
              {groupedFiles.map(({ dateLabel, files }) => (
                <div key={dateLabel} className="rounded-lg border border-border">
                  <button
                    onClick={() => toggleDate(dateLabel)}
                    className="flex w-full items-center gap-3 p-3 text-left hover:bg-secondary/50"
                  >
                    <ChevronRight 
                      className={`h-4 w-4 text-muted-foreground transition-transform ${
                        expandedDates.has(dateLabel) ? 'rotate-90' : ''
                      }`} 
                    />
                    <FileSpreadsheet className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium text-foreground">{dateLabel}</span>
                    <span className="text-muted-foreground">({files.length})</span>
                    
                    <div className="ml-4 flex flex-wrap items-center gap-2">
                      {/* Maps badges */}
                      {files.flatMap(f => f.maps).filter((v, i, a) => a.indexOf(v) === i).slice(0, 4).map(map => (
                        <span key={map} className="rounded bg-emerald-500/20 px-2 py-0.5 text-xs text-emerald-400">
                          {map}
                        </span>
                      ))}
                      {files.flatMap(f => f.maps).filter((v, i, a) => a.indexOf(v) === i).length > 4 && (
                        <span className="text-xs text-muted-foreground">
                          +{files.flatMap(f => f.maps).filter((v, i, a) => a.indexOf(v) === i).length - 4}
                        </span>
                      )}
                      
                      {/* Teams badges */}
                      {files.flatMap(f => f.teams).filter((v, i, a) => a.indexOf(v) === i).length > 0 && (
                        <>
                          <span className="text-muted-foreground">|</span>
                          {files.flatMap(f => f.teams).filter((v, i, a) => a.indexOf(v) === i).slice(0, 4).map(team => (
                            <span key={team} className="rounded bg-purple-500/20 px-2 py-0.5 text-xs text-purple-400">
                              {team}
                            </span>
                          ))}
                          {files.flatMap(f => f.teams).filter((v, i, a) => a.indexOf(v) === i).length > 4 && (
                            <span className="text-xs text-muted-foreground">
                              +{files.flatMap(f => f.teams).filter((v, i, a) => a.indexOf(v) === i).length - 4}
                            </span>
                          )}
                        </>
                      )}
                    </div>

                    <div className="ml-auto flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">{files[0].file_name}</span>
                      <Button variant="default" size="sm" className="gap-1">
                        <Pencil className="h-3 w-3" />
                        Edit
                      </Button>
                    </div>
                  </button>

                  {expandedDates.has(dateLabel) && files.length > 1 && (
                    <div className="border-t border-border">
                      {files.map(file => (
                        <div 
                          key={file.id}
                          className="flex items-center gap-3 border-b border-border/50 p-3 pl-10 last:border-b-0 hover:bg-secondary/30"
                        >
                          <FileSpreadsheet className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-foreground">{file.file_name}</span>
                          <div className="flex gap-1">
                            {file.maps.slice(0, 3).map(map => (
                              <span key={map} className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-xs text-emerald-400">
                                {map}
                              </span>
                            ))}
                          </div>
                          <span className="ml-auto text-xs text-muted-foreground">
                            {file.match_count} matches
                          </span>
                          <Button variant="outline" size="sm">Edit</Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
