'use client'

import React from "react"

import { useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Upload, FileSpreadsheet, Check, AlertCircle } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import * as XLSX from 'xlsx'

interface ParsedData {
  fileName: string
  scrimDate: string
  dateRangeEnd?: string
  maps: string[]
  teams: string[]
  matchCount: number
  statsJson: Record<string, unknown>
}

export function UploadDataPage() {
  const [dragOver, setDragOver] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [parsedData, setParsedData] = useState<ParsedData | null>(null)
  const [scrimDate, setScrimDate] = useState(new Date().toISOString().split('T')[0])
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const supabase = createClient()

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    const file = e.dataTransfer.files[0]
    if (file) processFile(file)
  }, [])

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) processFile(file)
  }

  async function processFile(file: File) {
    setError(null)
    setSuccess(false)
    
    if (!file.name.match(/\.(xlsx|xls)$/i)) {
      setError('Please upload an Excel file (.xlsx or .xls)')
      return
    }

    try {
      const data = await file.arrayBuffer()
      const workbook = XLSX.read(data, { type: 'array' })
      
      // Try to find Summary sheet or use first sheet
      const sheetName = workbook.SheetNames.find(n => 
        n.toLowerCase().includes('summary') || n.toLowerCase().includes('overview')
      ) || workbook.SheetNames[0]
      
      const sheet = workbook.Sheets[sheetName]
      const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 }) as unknown[][]

      // Parse the data
      const maps: Set<string> = new Set()
      const teams: Set<string> = new Set()
      let matchCount = 0

      // Look for map names in first column
      const valorantMaps = ['Abyss', 'Ascent', 'Bind', 'Breeze', 'Fracture', 'Haven', 'Icebox', 'Lotus', 'Pearl', 'Split', 'Sunset', 'Corrode']
      
      jsonData.forEach((row: unknown[]) => {
        if (row && row[0]) {
          const cellValue = String(row[0])
          // Check for map names
          valorantMaps.forEach(map => {
            if (cellValue.toLowerCase().includes(map.toLowerCase())) {
              maps.add(map)
            }
          })
          // Check for team names (usually 2-5 letter abbreviations in caps)
          if (/^[A-Z]{2,5}$/.test(cellValue)) {
            teams.add(cellValue)
          }
        }
      })

      // Count rows with data as matches
      matchCount = jsonData.filter((row: unknown[]) => 
        row && row.length > 3 && row.some(cell => cell !== null && cell !== '')
      ).length - 1 // Subtract header row

      const parsed: ParsedData = {
        fileName: file.name,
        scrimDate,
        maps: Array.from(maps),
        teams: Array.from(teams),
        matchCount: Math.max(matchCount, 1),
        statsJson: { 
          sheets: workbook.SheetNames,
          rawData: jsonData.slice(0, 50) // Store first 50 rows for preview
        }
      }

      setParsedData(parsed)
    } catch (err) {
      console.error('Error parsing file:', err)
      setError('Failed to parse Excel file')
    }
  }

  async function handleUpload() {
    if (!parsedData) return
    
    setUploading(true)
    setError(null)

    const { error: insertError } = await supabase
      .from('scrim_data_files')
      .insert([{
        file_name: parsedData.fileName,
        upload_date: new Date().toISOString(),
        date_start: scrimDate,
        maps: parsedData.maps,
        teams: parsedData.teams,
        match_count: parsedData.matchCount,
        stats: parsedData.statsJson
      }])

    if (insertError) {
      console.error('Error uploading:', insertError)
      setError('Failed to save file data')
    } else {
      setSuccess(true)
      setParsedData(null)
    }
    
    setUploading(false)
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Upload Data</h1>
        <p className="text-muted-foreground">
          Upload Excel files with scrim data to track and analyze your matches.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Upload Zone */}
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <Upload className="h-5 w-5 text-primary" />
              Upload Excel File
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-4 space-y-2">
              <Label htmlFor="scrim-date">Scrim Date</Label>
              <Input
                id="scrim-date"
                type="date"
                value={scrimDate}
                onChange={(e) => setScrimDate(e.target.value)}
                className="bg-input"
              />
            </div>

            <div
              onDrop={handleDrop}
              onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
              onDragLeave={() => setDragOver(false)}
              className={`flex flex-col items-center justify-center rounded-lg border-2 border-dashed p-8 transition-colors ${
                dragOver 
                  ? 'border-primary bg-primary/10' 
                  : 'border-border hover:border-primary/50'
              }`}
            >
              <FileSpreadsheet className="mb-4 h-12 w-12 text-muted-foreground" />
              <p className="mb-2 text-center text-foreground">
                Drag and drop your Excel file here
              </p>
              <p className="mb-4 text-center text-sm text-muted-foreground">
                or click to browse
              </p>
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleFileSelect}
                className="hidden"
                id="file-upload"
              />
              <Button asChild variant="outline">
                <label htmlFor="file-upload" className="cursor-pointer">
                  Browse Files
                </label>
              </Button>
            </div>

            {error && (
              <div className="mt-4 flex items-center gap-2 rounded-lg bg-destructive/10 p-3 text-destructive">
                <AlertCircle className="h-4 w-4" />
                {error}
              </div>
            )}

            {success && (
              <div className="mt-4 flex items-center gap-2 rounded-lg bg-emerald-500/10 p-3 text-emerald-500">
                <Check className="h-4 w-4" />
                File uploaded successfully!
              </div>
            )}
          </CardContent>
        </Card>

        {/* Preview */}
        {parsedData && (
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="text-card-foreground">File Preview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">File Name</p>
                <p className="font-medium text-foreground">{parsedData.fileName}</p>
              </div>

              <div>
                <p className="text-sm text-muted-foreground">Scrim Date</p>
                <p className="font-medium text-foreground">
                  {new Date(scrimDate).toLocaleDateString('en-US', { 
                    weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' 
                  })}
                </p>
              </div>

              <div>
                <p className="mb-2 text-sm text-muted-foreground">Maps Detected</p>
                <div className="flex flex-wrap gap-2">
                  {parsedData.maps.length > 0 ? (
                    parsedData.maps.map(map => (
                      <span key={map} className="rounded bg-emerald-500/20 px-2 py-1 text-sm text-emerald-400">
                        {map}
                      </span>
                    ))
                  ) : (
                    <span className="text-muted-foreground">No maps detected</span>
                  )}
                </div>
              </div>

              <div>
                <p className="mb-2 text-sm text-muted-foreground">Teams Detected</p>
                <div className="flex flex-wrap gap-2">
                  {parsedData.teams.length > 0 ? (
                    parsedData.teams.map(team => (
                      <span key={team} className="rounded bg-purple-500/20 px-2 py-1 text-sm text-purple-400">
                        {team}
                      </span>
                    ))
                  ) : (
                    <span className="text-muted-foreground">No teams detected</span>
                  )}
                </div>
              </div>

              <div>
                <p className="text-sm text-muted-foreground">Estimated Matches</p>
                <p className="font-medium text-foreground">{parsedData.matchCount}</p>
              </div>

              <Button 
                onClick={handleUpload} 
                disabled={uploading}
                className="w-full"
              >
                {uploading ? 'Uploading...' : 'Upload & Save'}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
