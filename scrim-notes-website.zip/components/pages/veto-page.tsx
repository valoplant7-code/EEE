'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Search, Ban, Target, Trophy, Swords, Plus, Trash2, ChevronRight, Check, FileText, Loader2, RefreshCw } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface VLRTeam {
  id: string
  name: string
  logo?: string
  country?: string
  ranking?: string
  region?: string
}

interface VLRVetoStats {
  bans: Array<{ map: string; count: number }>
  picks: Array<{ map: string; count: number }>
}

interface VLRMatch {
  team1: string
  team2: string
  score1: string
  score2: string
  date: string
  tournament: string
  tournamentIcon?: string
  matchPage?: string
  round?: string
  flag1?: string
  flag2?: string
}

interface VetoReport {
  id: string
  report_name: string
  team_name: string
  filters: {
    matchType: string
    tournament: string
    opponent: string
    dateFrom: string
    dateTo: string
  }
  map_stats: MapStats[]
  match_history: MatchHistory[]
  match_count: number
  status: 'complete' | 'in_progress'
  created_at: string
  updated_at: string
}

interface MapStats {
  map: string
  banRate: number
  roundWinRate: { atk: number; def: number }
  sidePickRate: { atk: number; def: number }
  teamBans: { first: number; second: number; third: number }
  teamPicks: { first: number; second: number; third: number }
  decider: { first: number; second: number }
}

interface MatchHistory {
  id: string
  date: string
  opponent: string
  tournament: string
  result: 'W' | 'L'
  score: string
  map: string
  ourBans: string[]
  theirBans: string[]
  ourPick: string
  theirPick: string
  decider?: string
}

// Sample data for demonstration
const sampleMapStats: MapStats[] = [
  { 
    map: 'Split', 
    banRate: 15.2, 
    roundWinRate: { atk: 52.3, def: 58.1 }, 
    sidePickRate: { atk: 45, def: 55 },
    teamBans: { first: 8, second: 12, third: 5 },
    teamPicks: { first: 18, second: 22, third: 0 },
    decider: { first: 6, second: 4 }
  },
  { 
    map: 'Haven', 
    banRate: 42.5, 
    roundWinRate: { atk: 48.2, def: 51.8 }, 
    sidePickRate: { atk: 52, def: 48 },
    teamBans: { first: 25, second: 18, third: 8 },
    teamPicks: { first: 5, second: 8, third: 0 },
    decider: { first: 2, second: 3 }
  },
  { 
    map: 'Bind', 
    banRate: 28.3, 
    roundWinRate: { atk: 55.1, def: 44.9 }, 
    sidePickRate: { atk: 62, def: 38 },
    teamBans: { first: 15, second: 20, third: 12 },
    teamPicks: { first: 12, second: 15, third: 0 },
    decider: { first: 4, second: 5 }
  },
  { 
    map: 'Abyss', 
    banRate: 55.0, 
    roundWinRate: { atk: 42.0, def: 58.0 }, 
    sidePickRate: { atk: 35, def: 65 },
    teamBans: { first: 30, second: 25, third: 10 },
    teamPicks: { first: 2, second: 3, third: 0 },
    decider: { first: 1, second: 2 }
  },
  { 
    map: 'Pearl', 
    banRate: 18.7, 
    roundWinRate: { atk: 51.2, def: 48.8 }, 
    sidePickRate: { atk: 50, def: 50 },
    teamBans: { first: 10, second: 8, third: 6 },
    teamPicks: { first: 20, second: 18, third: 0 },
    decider: { first: 8, second: 6 }
  },
]

const sampleMatchHistory: MatchHistory[] = [
  { id: '1', date: '2026-01-15', opponent: 'NAOS', tournament: 'VCT Challengers', result: 'W', score: '2-1', map: 'Split', ourBans: ['Haven', 'Abyss'], theirBans: ['Bind', 'Pearl'], ourPick: 'Split', theirPick: 'Breeze', decider: 'Ascent' },
  { id: '2', date: '2026-01-14', opponent: 'BLG', tournament: 'VCT Challengers', result: 'L', score: '1-2', map: 'Haven', ourBans: ['Abyss', 'Fracture'], theirBans: ['Split', 'Bind'], ourPick: 'Pearl', theirPick: 'Haven', decider: 'Lotus' },
  { id: '3', date: '2026-01-12', opponent: 'DRG', tournament: 'Scrim', result: 'W', score: '2-0', map: 'Bind', ourBans: ['Haven'], theirBans: ['Abyss'], ourPick: 'Bind', theirPick: 'Split' },
]

export function VetoPage() {
  const [view, setView] = useState<'list' | 'search' | 'detail'>('list')
  const [savedReports, setSavedReports] = useState<VetoReport[]>([])
  const [selectedReport, setSelectedReport] = useState<VetoReport | null>(null)
  const [loading, setLoading] = useState(true)
  
  // Search state
  const [teamSearch, setTeamSearch] = useState('')
  const [matchType, setMatchType] = useState('all')
  const [tournament, setTournament] = useState('all')
  const [opponent, setOpponent] = useState('')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [hasSearched, setHasSearched] = useState(false)
  const [mapStats, setMapStats] = useState<MapStats[]>([])
  const [matchHistory, setMatchHistory] = useState<MatchHistory[]>([])
  
  // Save dialog state
  const [saveDialogOpen, setSaveDialogOpen] = useState(false)
  const [reportName, setReportName] = useState('')
  
  // VLR API state
  const [searchResults, setSearchResults] = useState<VLRTeam[]>([])
  const [selectedTeam, setSelectedTeam] = useState<VLRTeam | null>(null)
  const [searching, setSearching] = useState(false)
  const [fetchingMatches, setFetchingMatches] = useState(false)
  const [vlrMatches, setVlrMatches] = useState<VLRMatch[]>([])

  const supabase = createClient()

  useEffect(() => {
    fetchReports()
  }, [])

  async function fetchReports() {
    setLoading(true)
    const { data, error } = await supabase
      .from('veto_reports')
      .select('*')
      .order('updated_at', { ascending: false })

    if (error) {
      console.error('Error fetching reports:', error)
    } else {
      setSavedReports(data || [])
    }
    setLoading(false)
  }

  async function searchVLRTeams() {
    if (!teamSearch.trim()) return
    setSearching(true)
    try {
      // Use the new team search endpoint that scrapes VLR directly
      const response = await fetch(`/api/vlr/team-search?q=${encodeURIComponent(teamSearch)}`)
      const data = await response.json()
      setSearchResults(data.teams || [])
    } catch (error) {
      console.error('Search error:', error)
      setSearchResults([])
    }
    setSearching(false)
  }

  async function fetchVLRMatches() {
    if (!selectedTeam?.id) return
    setFetchingMatches(true)
    try {
      // Use the new veto scraper endpoint
      const response = await fetch(`/api/vlr/team-veto?teamId=${selectedTeam.id}&pages=2`)
      const data = await response.json()
      
      if (data.error) {
        console.error('API error:', data.error)
        setFetchingMatches(false)
        return
      }
      
      // Convert scraped matches to our format
      const converted: MatchHistory[] = (data.matches || []).map((m: {
        matchId: string
        opponent: string
        date: string
        tournament: string
        score: string
        bans: string[]
        picks: string[]
        decider: string | null
      }, i: number) => ({
        id: m.matchId || String(i),
        date: m.date || 'Recently',
        opponent: m.opponent || 'Unknown',
        tournament: m.tournament || 'Unknown Event',
        result: 'W' as 'W' | 'L', // Would need to parse score
        score: m.score || '0-0',
        map: m.picks[0] || m.decider || 'Unknown',
        ourBans: m.bans,
        theirBans: [],
        ourPick: m.picks[0] || '',
        theirPick: ''
      }))
      
      // Generate map stats from scraped veto statistics
      const vetoStats = data.statistics as VLRVetoStats
      const allMaps = ['Abyss', 'Bind', 'Breeze', 'Haven', 'Icebox', 'Lotus', 'Pearl', 'Split', 'Sunset']
      
      const totalBans = vetoStats?.bans?.reduce((sum, b) => sum + b.count, 0) || 1
      const totalPicks = vetoStats?.picks?.reduce((sum, p) => sum + p.count, 0) || 1
      
      const mapStatsFromVeto: MapStats[] = allMaps.map(mapName => {
        const banData = vetoStats?.bans?.find(b => b.map.toLowerCase() === mapName.toLowerCase())
        const pickData = vetoStats?.picks?.find(p => p.map.toLowerCase() === mapName.toLowerCase())
        
        return {
          map: mapName,
          banRate: banData ? (banData.count / totalBans) * 100 : 0,
          roundWinRate: { atk: 50, def: 50 }, // Not available from veto data
          sidePickRate: { atk: 50, def: 50 },
          teamBans: { 
            first: banData?.count || 0, 
            second: 0, 
            third: 0 
          },
          teamPicks: { 
            first: pickData?.count || 0, 
            second: 0, 
            third: 0 
          }
        }
      }).filter(s => s.banRate > 0 || s.teamPicks.first > 0)
      
      setMatchHistory(converted)
      setMapStats(mapStatsFromVeto.length > 0 ? mapStatsFromVeto : sampleMapStats)
      setHasSearched(true)
      setVlrMatches(data.matches || [])
    } catch (error) {
      console.error('Fetch error:', error)
    }
    setFetchingMatches(false)
  }

  function handleSearch() {
    if (selectedTeam) {
      fetchVLRMatches()
    } else {
      setMapStats(sampleMapStats)
      setMatchHistory(sampleMatchHistory)
      setHasSearched(true)
    }
  }

  async function handleSaveReport() {
    if (!reportName.trim() || !teamSearch.trim()) return

    const report = {
      report_name: reportName,
      team_name: teamSearch,
      filters: {
        matchType,
        tournament,
        opponent,
        dateFrom,
        dateTo
      },
      map_stats: mapStats,
      match_history: matchHistory,
      match_count: matchHistory.length,
      status: 'complete' as const
    }

    const { error } = await supabase
      .from('veto_reports')
      .insert([report])

    if (error) {
      console.error('Error saving report:', error)
    } else {
      setSaveDialogOpen(false)
      setReportName('')
      fetchReports()
      setView('list')
    }
  }

  async function handleDeleteReport(id: string) {
    const { error } = await supabase
      .from('veto_reports')
      .delete()
      .eq('id', id)

    if (error) {
      console.error('Error deleting report:', error)
    } else {
      fetchReports()
    }
  }

  function openReport(report: VetoReport) {
    setSelectedReport(report)
    setMapStats(report.map_stats || [])
    setMatchHistory(report.match_history || [])
    setTeamSearch(report.team_name)
    setView('detail')
  }

  function startNewReport() {
    setTeamSearch('')
    setMatchType('all')
    setTournament('all')
    setOpponent('')
    setDateFrom('')
    setDateTo('')
    setHasSearched(false)
    setMapStats([])
    setMatchHistory([])
    setSelectedReport(null)
    setSearchResults([])
    setSelectedTeam(null)
    setVlrMatches([])
    setView('search')
  }

  const mostBannedMap = mapStats.length > 0 
    ? mapStats.reduce((a, b) => a.banRate > b.banRate ? a : b).map 
    : '-'
  
  const mostPickedMap = mapStats.length > 0
    ? mapStats.reduce((a, b) => (a.teamPicks.first + a.teamPicks.second) > (b.teamPicks.first + b.teamPicks.second) ? a : b).map
    : '-'

  const overallWinRate = matchHistory.length > 0
    ? ((matchHistory.filter(m => m.result === 'W').length / matchHistory.length) * 100).toFixed(1) + '%'
    : '-'

  // List View - Saved Reports
  if (view === 'list') {
    return (
      <div className="p-6">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Map Veto Analysis</h1>
            <p className="text-muted-foreground">Analyze opponent map pools and optimize your veto strategy</p>
          </div>
          <Button onClick={startNewReport}>
            <Plus className="mr-2 h-4 w-4" />
            New Report
          </Button>
        </div>

        <Card className="border-border bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              Saved Reports
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="py-8 text-center text-muted-foreground">Loading reports...</div>
            ) : savedReports.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground">
                No saved reports yet. Click "New Report" to create one.
              </div>
            ) : (
              <div className="space-y-2">
                {savedReports.map((report) => (
                  <div
                    key={report.id}
                    className="flex items-center gap-4 rounded-lg border border-border p-4 transition-colors hover:bg-secondary/50"
                  >
                    <div className={`rounded px-2 py-1 text-xs font-medium ${
                      report.status === 'complete' 
                        ? 'bg-green-500/20 text-green-500' 
                        : 'bg-amber-500/20 text-amber-500'
                    }`}>
                      <Check className="mr-1 inline h-3 w-3" />
                      {report.status === 'complete' ? 'Complete' : 'In Progress'}
                    </div>
                    
                    <div className="flex-1">
                      <p className="font-medium text-foreground">
                        {report.report_name} <span className="text-muted-foreground">({report.team_name})</span>
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {report.match_count} matches analyzed • Updated {new Date(report.updated_at).toLocaleDateString()}
                      </p>
                    </div>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openReport(report)}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation()
                        handleDeleteReport(report.id)
                      }}
                      className="text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  // Search/Detail View
  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setView('list')}>
              Saved Reports
            </Button>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
            <span className="text-foreground">{view === 'detail' ? selectedReport?.report_name : 'New Report'}</span>
          </div>
          <h1 className="mt-2 text-2xl font-bold text-foreground">
            {view === 'detail' ? selectedReport?.report_name : 'Map Veto Analysis'}
          </h1>
        </div>
        {hasSearched && view === 'search' && (
          <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                Save Report
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Save Veto Report</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label>Report Name</Label>
                  <Input
                    placeholder="e.g., VARREL kickoff 1"
                    value={reportName}
                    onChange={(e) => setReportName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Team</Label>
                  <Input value={teamSearch} disabled />
                </div>
                <Button onClick={handleSaveReport} className="w-full">
                  Save Report
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Search Section */}
      {view === 'search' && (
        <Card className="mb-6 border-border bg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Search className="h-5 w-5 text-primary" />
              Team Search
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <div className="space-y-2">
                <Label>Team Name (VLR.gg)</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Search team on VLR.gg..."
                    value={teamSearch}
                    onChange={(e) => {
                      setTeamSearch(e.target.value)
                      setSelectedTeam(null)
                    }}
                    onKeyDown={(e) => e.key === 'Enter' && searchVLRTeams()}
                  />
                  <Button onClick={searchVLRTeams} disabled={searching} size="icon" variant="outline">
                    {searching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                  </Button>
                </div>
                
                {/* Search Results Dropdown */}
                {searchResults.length > 0 && !selectedTeam && (
                  <div className="max-h-48 overflow-y-auto rounded-lg border border-border bg-popover">
{searchResults.map((team, idx) => (
                      <button
                        key={team.id || idx}
                        className="flex w-full items-center gap-3 p-3 text-left hover:bg-secondary transition-colors"
                        onClick={() => {
                          setSelectedTeam(team)
                          setTeamSearch(team.name)
                          setSearchResults([])
                        }}
                      >
                        {team.logo && <img src={team.logo || '/placeholder.svg'} alt="" className="h-6 w-6 rounded" />}
                        <div>
                          <p className="font-medium text-foreground">{team.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {team.region && <span className="text-primary">{team.region}</span>}
                            {team.ranking && <span> #{team.ranking}</span>}
                            {team.id && <span className="text-muted-foreground/60"> (ID: {team.id})</span>}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
                
                {/* Selected Team Badge */}
                {selectedTeam && (
                  <div className="flex items-center gap-2 rounded-lg border border-primary bg-primary/5 p-2">
                    {selectedTeam.logo && <img src={selectedTeam.logo || "/placeholder.svg"} alt="" className="h-6 w-6 rounded" />}
                    <span className="font-medium text-foreground">{selectedTeam.name}</span>
                    <Button variant="ghost" size="sm" className="ml-auto h-6 px-2" onClick={() => setSelectedTeam(null)}>
                      Change
                    </Button>
                  </div>
                )}
              </div>
              
              <div className="space-y-2">
                <Label>Match Type</Label>
                <Select value={matchType} onValueChange={setMatchType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Match Types</SelectItem>
                    <SelectItem value="bo1">Best of 1</SelectItem>
                    <SelectItem value="bo3">Best of 3</SelectItem>
                    <SelectItem value="bo5">Best of 5</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Tournament</Label>
                <Select value={tournament} onValueChange={setTournament}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Tournaments</SelectItem>
                    <SelectItem value="vct">VCT Challengers</SelectItem>
                    <SelectItem value="scrim">Scrims</SelectItem>
                    <SelectItem value="ranked">Ranked</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Opponent</Label>
                <Input
                  placeholder="Filter by opponent..."
                  value={opponent}
                  onChange={(e) => setOpponent(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>Date From</Label>
                <Input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>Date To</Label>
                <Input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                />
              </div>
            </div>

            <Button onClick={handleSearch} className="mt-4" disabled={fetchingMatches}>
              {fetchingMatches ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Fetching Data...</>
              ) : (
                <><RefreshCw className="mr-2 h-4 w-4" /> Fetch Match Data</>
              )}
            </Button>
            
            {vlrMatches.length > 0 && (
              <p className="mt-2 text-sm text-muted-foreground">
                Found {vlrMatches.length} matches from VLR.gg
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {!hasSearched && view === 'search' && (
        <div className="flex h-64 items-center justify-center rounded-lg border border-dashed border-border">
          <p className="text-muted-foreground">Search for a team to view their map veto patterns</p>
        </div>
      )}

      {(hasSearched || view === 'detail') && (
        <>
          {/* Stats Summary */}
          <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Card className="border-border bg-card">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-primary/10 p-2">
                    <Swords className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Matches Analyzed</p>
                    <p className="text-2xl font-bold text-foreground">{matchHistory.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-red-500/10 p-2">
                    <Ban className="h-5 w-5 text-red-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Most Banned Map</p>
                    <p className="text-2xl font-bold text-foreground">{mostBannedMap}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-green-500/10 p-2">
                    <Target className="h-5 w-5 text-green-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Most Picked Map</p>
                    <p className="text-2xl font-bold text-foreground">{mostPickedMap}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-blue-500/10 p-2">
                    <Trophy className="h-5 w-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Overall Win Rate</p>
                    <p className="text-2xl font-bold text-foreground">{overallWinRate}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabs for Patterns and Match History */}
          <Tabs defaultValue="patterns" className="space-y-4">
            <TabsList>
              <TabsTrigger value="patterns">Patterns</TabsTrigger>
              <TabsTrigger value="history">Match History</TabsTrigger>
            </TabsList>

            <TabsContent value="patterns">
              <Card className="border-border bg-card">
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-border">
                          <TableHead rowSpan={2} className="border-r border-border">Map</TableHead>
                          <TableHead rowSpan={2} className="border-r border-border text-center">Ban Rate</TableHead>
                          <TableHead colSpan={2} className="border-r border-border text-center">Round Winrate</TableHead>
                          <TableHead colSpan={2} className="border-r border-border text-center">Side Pickrate</TableHead>
                          <TableHead colSpan={3} className="border-r border-border text-center">Team Bans</TableHead>
                          <TableHead colSpan={3} className="border-r border-border text-center">Team Picks</TableHead>
                          <TableHead colSpan={2} className="text-center">Decider</TableHead>
                        </TableRow>
                        <TableRow className="border-border">
                          <TableHead className="text-center text-xs">ATK</TableHead>
                          <TableHead className="border-r border-border text-center text-xs">DEF</TableHead>
                          <TableHead className="text-center text-xs">ATK</TableHead>
                          <TableHead className="border-r border-border text-center text-xs">DEF</TableHead>
                          <TableHead className="text-center text-xs">1st</TableHead>
                          <TableHead className="text-center text-xs">2nd</TableHead>
                          <TableHead className="border-r border-border text-center text-xs">3rd</TableHead>
                          <TableHead className="text-center text-xs">1st</TableHead>
                          <TableHead className="text-center text-xs">2nd</TableHead>
                          <TableHead className="border-r border-border text-center text-xs">3rd</TableHead>
                          <TableHead className="text-center text-xs">1st</TableHead>
                          <TableHead className="text-center text-xs">2nd</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {mapStats.map((stat) => (
                          <TableRow key={stat.map} className="border-border">
                            <TableCell className="border-r border-border font-medium">{stat.map}</TableCell>
                            <TableCell className="border-r border-border text-center">
                              <span className={stat.banRate > 40 ? 'text-red-500' : stat.banRate > 25 ? 'text-amber-500' : 'text-green-500'}>
                                {stat.banRate.toFixed(1)}%
                              </span>
                            </TableCell>
                            <TableCell className="text-center">
                              <span className={stat.roundWinRate.atk >= 50 ? 'text-green-500' : 'text-red-500'}>
                                {stat.roundWinRate.atk.toFixed(1)}%
                              </span>
                            </TableCell>
                            <TableCell className="border-r border-border text-center">
                              <span className={stat.roundWinRate.def >= 50 ? 'text-green-500' : 'text-red-500'}>
                                {stat.roundWinRate.def.toFixed(1)}%
                              </span>
                            </TableCell>
                            <TableCell className="text-center">{stat.sidePickRate.atk}%</TableCell>
                            <TableCell className="border-r border-border text-center">{stat.sidePickRate.def}%</TableCell>
                            <TableCell className="text-center">{stat.teamBans.first}</TableCell>
                            <TableCell className="text-center">{stat.teamBans.second}</TableCell>
                            <TableCell className="border-r border-border text-center">{stat.teamBans.third}</TableCell>
                            <TableCell className="text-center">{stat.teamPicks.first}</TableCell>
                            <TableCell className="text-center">{stat.teamPicks.second}</TableCell>
                            <TableCell className="border-r border-border text-center">{stat.teamPicks.third}</TableCell>
                            <TableCell className="text-center">{stat.decider.first}</TableCell>
                            <TableCell className="text-center">{stat.decider.second}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="history">
              <Card className="border-border bg-card">
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-border">
                          <TableHead>Date</TableHead>
                          <TableHead>Opponent</TableHead>
                          <TableHead>Tournament</TableHead>
                          <TableHead className="text-center">Result</TableHead>
                          <TableHead className="text-center">Score</TableHead>
                          <TableHead>Our Bans</TableHead>
                          <TableHead>Their Bans</TableHead>
                          <TableHead>Our Pick</TableHead>
                          <TableHead>Their Pick</TableHead>
                          <TableHead>Decider</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {matchHistory.map((match) => (
                          <TableRow key={match.id} className="border-border">
                            <TableCell className="whitespace-nowrap">
                              {new Date(match.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                            </TableCell>
                            <TableCell className="font-medium">{match.opponent}</TableCell>
                            <TableCell className="text-muted-foreground">{match.tournament}</TableCell>
                            <TableCell className="text-center">
                              <span className={`inline-flex h-6 w-6 items-center justify-center rounded text-xs font-bold ${match.result === 'W' ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'}`}>
                                {match.result}
                              </span>
                            </TableCell>
                            <TableCell className="text-center font-medium">{match.score}</TableCell>
                            <TableCell>
                              <div className="flex flex-wrap gap-1">
                                {match.ourBans.map((map) => (
                                  <span key={map} className="rounded bg-red-500/20 px-1.5 py-0.5 text-xs text-red-400">{map}</span>
                                ))}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-wrap gap-1">
                                {match.theirBans.map((map) => (
                                  <span key={map} className="rounded bg-orange-500/20 px-1.5 py-0.5 text-xs text-orange-400">{map}</span>
                                ))}
                              </div>
                            </TableCell>
                            <TableCell>
                              <span className="rounded bg-green-500/20 px-1.5 py-0.5 text-xs text-green-400">{match.ourPick}</span>
                            </TableCell>
                            <TableCell>
                              <span className="rounded bg-blue-500/20 px-1.5 py-0.5 text-xs text-blue-400">{match.theirPick}</span>
                            </TableCell>
                            <TableCell>
                              {match.decider && (
                                <span className="rounded bg-purple-500/20 px-1.5 py-0.5 text-xs text-purple-400">{match.decider}</span>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  )
}
