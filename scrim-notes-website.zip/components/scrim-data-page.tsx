'use client'

import { useState, useEffect } from 'react'
import { BarChart3, RefreshCw } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { AddMatchForm } from './add-match-form'
import { StatsOverview } from './stats-overview'
import { MatchList } from './match-list'
import { ExcelUpload } from './excel-upload'
import type { ScrimMatch, PlayerStat } from '@/lib/types'

export function ScrimDataPage() {
  const [matches, setMatches] = useState<ScrimMatch[]>([])
  const [playerStats, setPlayerStats] = useState<PlayerStat[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    fetchData()
  }, [])

  async function fetchData() {
    setLoading(true)
    
    const [matchesRes, statsRes] = await Promise.all([
      supabase.from('scrim_matches').select('*').order('match_date', { ascending: false }),
      supabase.from('player_stats').select('*')
    ])

    if (matchesRes.error) console.error('Error fetching matches:', matchesRes.error)
    else setMatches(matchesRes.data || [])

    if (statsRes.error) console.error('Error fetching stats:', statsRes.error)
    else setPlayerStats(statsRes.data || [])

    setLoading(false)
  }

  async function handleAddMatch(data: {
    date: string
    opponent: string
    map: string
    our_score: number
    their_score: number
    vod_url?: string
    notes?: string
    player_stats: Array<{
      player_name: string
      agent: string
      kills: number
      deaths: number
      assists: number
      acs: number
      adr: number
      first_kills: number
      first_deaths: number
    }>
  }) {
    const result: 'win' | 'loss' | 'draw' = 
      data.our_score > data.their_score ? 'win' : 
      data.our_score < data.their_score ? 'loss' : 'draw'

    const { data: match, error: matchError } = await supabase
      .from('scrim_matches')
      .insert([{
        match_date: data.date,
        opponent_name: data.opponent,
        map: data.map,
        our_score: data.our_score,
        enemy_score: data.their_score,
        vod_url: data.vod_url,
        notes: data.notes
      }])
      .select()
      .single()

    if (matchError) {
      console.error('Error adding match:', matchError)
      return
    }

    if (match && data.player_stats.length > 0) {
      const statsToInsert = data.player_stats.map(stat => ({
        ...stat,
        match_id: match.id
      }))

      const { data: newStats, error: statsError } = await supabase
        .from('player_stats')
        .insert(statsToInsert)
        .select()

      if (statsError) {
        console.error('Error adding player stats:', statsError)
      } else if (newStats) {
        setPlayerStats(prev => [...newStats, ...prev])
      }
    }

    setMatches(prev => [match, ...prev])
  }

  async function handleDeleteMatch(id: string) {
    const { error } = await supabase
      .from('scrim_matches')
      .delete()
      .eq('id', id)

    if (error) {
      console.error('Error deleting match:', error)
    } else {
      setMatches(prev => prev.filter(m => m.id !== id))
      setPlayerStats(prev => prev.filter(s => s.match_id !== id))
    }
  }

  async function handleExcelImport(parsedMatches: Array<{
    team: string
    map: string
    date: string
    roundsWon: number
    roundsLost: number
    side?: string
    rounds?: Array<{
      map: string
      team: string
      round: number
      side: 'ATK' | 'DEF'
      roundWin?: boolean
    }>
    stats?: {
      fkPercent?: number
      fkWinPercent?: number
      plantPercent?: number
      postPercent?: number
      retakePercent?: number
    }
    players: Array<{
      name: string
      agent: string
      acs: number
      kills: number
      deaths: number
      assists: number
      firstKills: number
    }>
  }>) {
    for (const match of parsedMatches) {
      // Build notes with round-by-round stats if available
      let notes = ''
      if (match.rounds && match.rounds.length > 0) {
        const atkRounds = match.rounds.filter(r => r.side === 'ATK')
        const defRounds = match.rounds.filter(r => r.side === 'DEF')
        const atkWins = atkRounds.filter(r => r.roundWin === true).length
        const defWins = defRounds.filter(r => r.roundWin === true).length
        notes = `ATK: ${atkWins}/${atkRounds.length} | DEF: ${defWins}/${defRounds.length}`
      }
      if (match.stats) {
        const statParts = []
        if (match.stats.fkPercent) statParts.push(`FK: ${match.stats.fkPercent.toFixed(0)}%`)
        if (match.stats.plantPercent) statParts.push(`Plant: ${match.stats.plantPercent.toFixed(0)}%`)
        if (match.stats.retakePercent) statParts.push(`Retake: ${match.stats.retakePercent.toFixed(0)}%`)
        if (statParts.length > 0) {
          notes = notes ? `${notes} | ${statParts.join(', ')}` : statParts.join(', ')
        }
      }

      const { data: insertedMatch, error: matchError } = await supabase
        .from('scrim_matches')
        .insert([{
          match_date: match.date,
          opponent_name: match.team,
          map: match.map || 'Unknown',
          our_score: match.roundsWon,
          enemy_score: match.roundsLost,
          notes: notes || undefined
        }])
        .select()
        .single()

      if (matchError) {
        console.error('Error importing match:', matchError)
        continue
      }

      if (insertedMatch && match.players.length > 0) {
        const statsToInsert = match.players.map(p => ({
          match_id: insertedMatch.id,
          player_name: p.name,
          agent: p.agent || 'Unknown',
          kills: p.kills,
          deaths: p.deaths,
          assists: p.assists,
          acs: p.acs,
          adr: 0,
          first_kills: p.firstKills,
          first_deaths: 0
        }))

        const { error: statsError } = await supabase
          .from('player_stats')
          .insert(statsToInsert)

        if (statsError) {
          console.error('Error importing player stats:', statsError)
        }
      }
    }

    // Refresh data after import
    await fetchData()
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/20">
          <BarChart3 className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Scrim Data</h1>
          <p className="text-sm text-muted-foreground">
            Track match results, player performance, and identify areas to improve.
          </p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <AddMatchForm onSubmit={handleAddMatch} />
        <ExcelUpload onImport={handleExcelImport} />
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <RefreshCw className="h-6 w-6 animate-spin text-primary" />
        </div>
      ) : (
        <>
          <StatsOverview matches={matches} playerStats={playerStats} />
          <MatchList matches={matches} onDelete={handleDeleteMatch} />
        </>
      )}
    </div>
  )
}
