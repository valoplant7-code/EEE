'use client'

import { useState } from 'react'
import { Sidebar, type PageType } from '@/components/sidebar'
import { MetricsPage } from '@/components/pages/metrics-page'
import { InsightsPage } from '@/components/pages/insights-page'
import { UploadDataPage } from '@/components/pages/upload-data-page'
import { EditDataPage } from '@/components/pages/edit-data-page'
import { ScrimNotesPage } from '@/components/scrim-notes-page'
import { ScrimDataPage } from '@/components/scrim-data-page'
import { VetoPage } from '@/components/pages/veto-page'

export default function Home() {
  const [activePage, setActivePage] = useState<PageType>('metrics')
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  function renderPage() {
    switch (activePage) {
      case 'metrics':
        return <MetricsPage />
      case 'insights':
        return <InsightsPage />
      case 'upload':
        return <UploadDataPage />
      case 'edit-data':
        return <EditDataPage />
      case 'manual-input':
        return <ScrimDataPage />
      case 'notes':
        return <ScrimNotesPage />
      case 'calendar':
        return <PlaceholderPage title="Calendar View" desc="View scrims by date" />
      case 'vods':
        return <PlaceholderPage title="VOD Management" desc="Link VODs to scrims" />
      case 'veto':
        return <VetoPage />
      default:
        return <MetricsPage />
    }
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar
        activePage={activePage}
        onPageChange={setActivePage}
        collapsed={sidebarCollapsed}
        onCollapsedChange={setSidebarCollapsed}
      />
      <main className="flex-1 overflow-y-auto">
        {renderPage()}
      </main>
    </div>
  )
}

function PlaceholderPage({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="flex h-full items-center justify-center p-6">
      <div className="text-center">
        <p className="text-xl font-medium text-foreground">{title}</p>
        <p className="text-muted-foreground">Coming soon - {desc}</p>
      </div>
    </div>
  )
}
