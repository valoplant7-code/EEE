import { NextResponse } from 'next/server'

const VLR_API_BASE = 'https://vlrggapi.vercel.app'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get('q')
  const type = searchParams.get('type') || 'teams'

  if (!query) {
    return NextResponse.json({ error: 'Query required' }, { status: 400 })
  }

  try {
    if (type === 'teams') {
      // Fetch rankings from multiple regions and search
      const regions = ['na', 'eu', 'ap', 'kr', 'jp', 'br', 'latam', 'cn']
      const allTeams: Array<{ name: string; logo: string; country: string; ranking: string; region: string }> = []
      
      // Fetch from first few regions in parallel
      const regionPromises = regions.slice(0, 4).map(async (region) => {
        try {
          const res = await fetch(`${VLR_API_BASE}/rankings?region=${region}`, {
            next: { revalidate: 3600 } // Cache for 1 hour
          })
          if (!res.ok) return []
          const data = await res.json()
          return (data.data || []).map((team: { team: string; logo: string; country: string; rank: string }) => ({
            name: team.team,
            logo: team.logo?.startsWith('//') ? `https:${team.logo}` : team.logo,
            country: team.country,
            ranking: team.rank,
            region: region.toUpperCase()
          }))
        } catch {
          return []
        }
      })
      
      const results = await Promise.all(regionPromises)
      results.forEach(teams => allTeams.push(...teams))
      
      // Filter by search query
      const matchedTeams = allTeams.filter(team => 
        team.name.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 15)
      
      return NextResponse.json({ teams: matchedTeams })
    }

    return NextResponse.json({ teams: [] })
  } catch (error) {
    console.error('VLR API error:', error)
    return NextResponse.json({ error: 'Failed to fetch from VLR API' }, { status: 500 })
  }
}
