import { NextResponse } from 'next/server'

const VLR_API_BASE = 'https://vlrggapi.vercel.app'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const team = searchParams.get('team')

  if (!team) {
    return NextResponse.json({ error: 'Team name required' }, { status: 400 })
  }

  try {
    // Fetch recent match results from VLR API
    const response = await fetch(`${VLR_API_BASE}/match?q=results`, {
      next: { revalidate: 300 } // Cache for 5 minutes
    })
    
    if (!response.ok) {
      throw new Error(`VLR API returned ${response.status}`)
    }
    
    const data = await response.json()

    if (data.data && data.data.segments) {
      // Filter matches that include the team
      const teamMatches = data.data.segments.filter((match: { 
        team1: string
        team2: string 
      }) => 
        match.team1?.toLowerCase().includes(team.toLowerCase()) ||
        match.team2?.toLowerCase().includes(team.toLowerCase())
      ).slice(0, 50).map((match: {
        team1: string
        team2: string
        score1: string
        score2: string
        flag1: string
        flag2: string
        time_completed: string
        match_page: string
        tournament_name: string
        tournament_icon: string
        round_info: string
      }) => ({
        team1: match.team1,
        team2: match.team2,
        score1: match.score1,
        score2: match.score2,
        flag1: match.flag1,
        flag2: match.flag2,
        date: match.time_completed,
        matchPage: match.match_page ? `https://vlr.gg${match.match_page}` : null,
        tournament: match.tournament_name,
        tournamentIcon: match.tournament_icon?.startsWith('//') ? `https:${match.tournament_icon}` : match.tournament_icon,
        round: match.round_info
      }))

      return NextResponse.json({ 
        matches: teamMatches,
        total: teamMatches.length,
        source: 'vlr.gg'
      })
    }

    return NextResponse.json({ matches: [], total: 0 })
  } catch (error) {
    console.error('VLR API error:', error)
    return NextResponse.json({ error: 'Failed to fetch matches from VLR.gg' }, { status: 500 })
  }
}
