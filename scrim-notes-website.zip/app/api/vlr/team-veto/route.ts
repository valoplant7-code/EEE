import { NextResponse } from 'next/server'

// Scrape VLR.gg team matches page to get veto data
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const teamId = searchParams.get('teamId')
  const pages = parseInt(searchParams.get('pages') || '1')

  if (!teamId) {
    return NextResponse.json({ error: 'teamId is required' }, { status: 400 })
  }

  try {
    const allMatches: Array<{
      matchId: string
      opponent: string
      date: string
      tournament: string
      score: string
      bans: string[]
      picks: string[]
      decider: string | null
    }> = []

    // Fetch each page of matches
    for (let page = 1; page <= Math.min(pages, 5); page++) {
      const matchesUrl = `https://www.vlr.gg/team/matches/${teamId}?page=${page}`
      
      const matchesRes = await fetch(matchesUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      })
      
      if (!matchesRes.ok) continue
      
      const matchesHtml = await matchesRes.text()
      
      // Extract team name
      const teamNameMatch = matchesHtml.match(/<h2 class="wf-title[^"]*">([^<]+)<\/h2>/)
      const teamName = teamNameMatch ? teamNameMatch[1].trim() : ''
      
      // Extract match links - look for match IDs in the page
      const matchLinkRegex = /href="\/(\d+)\/[^"]*"[^>]*class="[^"]*wf-card[^"]*mod-dark/g
      const matchIds: string[] = []
      let match
      
      while ((match = matchLinkRegex.exec(matchesHtml)) !== null) {
        if (!matchIds.includes(match[1])) {
          matchIds.push(match[1])
        }
      }
      
      // For each match, fetch the match page to get veto data
      for (const matchId of matchIds.slice(0, 10)) { // Limit to 10 per page
        try {
          const matchUrl = `https://www.vlr.gg/${matchId}`
          const matchRes = await fetch(matchUrl, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
          })
          
          if (!matchRes.ok) continue
          
          const matchHtml = await matchRes.text()
          
          // Extract veto section
          const vetoMatch = matchHtml.match(/class="match-header-vs-note[^"]*mod-map"[^>]*>([\s\S]*?)<\/div>/)
          const vetoText = vetoMatch ? vetoMatch[1] : ''
          
          // Parse bans and picks for our team
          const bans: string[] = []
          const picks: string[] = []
          let decider: string | null = null
          
          // Look for veto actions: "TEAM ban MAP" or "TEAM pick MAP"
          const vetoLines = vetoText.split(/[;\n]/).filter(line => line.trim())
          
          for (const line of vetoLines) {
            const lowerLine = line.toLowerCase()
            if (lowerLine.includes(teamName.toLowerCase() + ' ban')) {
              const mapMatch = line.match(/ban\s+(\w+)/i)
              if (mapMatch) bans.push(mapMatch[1])
            } else if (lowerLine.includes(teamName.toLowerCase() + ' pick')) {
              const mapMatch = line.match(/pick\s+(\w+)/i)
              if (mapMatch) picks.push(mapMatch[1])
            } else if (lowerLine.includes('decider') || lowerLine.includes('remains')) {
              const mapMatch = line.match(/(\w+)\s+(?:decider|remains)/i)
              if (mapMatch) decider = mapMatch[1]
            }
          }
          
          // Extract opponent and score
          const teamsMatch = matchHtml.match(/class="match-header-link-name[^"]*"[^>]*>[\s\S]*?<div[^>]*>([^<]+)<\/div>[\s\S]*?class="match-header-link-name[^"]*"[^>]*>[\s\S]*?<div[^>]*>([^<]+)<\/div>/g)
          const scoreMatch = matchHtml.match(/class="match-header-vs-score[^"]*"[^>]*>[\s\S]*?<span>(\d+)<\/span>[\s\S]*?<span>(\d+)<\/span>/i)
          
          // Extract tournament name
          const tournamentMatch = matchHtml.match(/class="match-header-event[^"]*"[^>]*>[\s\S]*?<div[^>]*style[^>]*>([^<]+)<\/div>/i)
          const tournament = tournamentMatch ? tournamentMatch[1].trim() : 'Unknown'
          
          // Extract date
          const dateMatch = matchHtml.match(/class="moment-tz-convert"[^>]*data-utc-ts="([^"]+)"/)
          const date = dateMatch ? new Date(dateMatch[1]).toLocaleDateString() : ''
          
          allMatches.push({
            matchId,
            opponent: '', // Will be filled from page context
            date,
            tournament,
            score: scoreMatch ? `${scoreMatch[1]}-${scoreMatch[2]}` : '',
            bans,
            picks,
            decider
          })
          
          // Add small delay to avoid rate limiting
          await new Promise(resolve => setTimeout(resolve, 200))
        } catch (err) {
          console.error(`Error fetching match ${matchId}:`, err)
        }
      }
    }

    // Calculate statistics
    const banCounts: Record<string, number> = {}
    const pickCounts: Record<string, number> = {}
    
    for (const match of allMatches) {
      for (const ban of match.bans) {
        banCounts[ban] = (banCounts[ban] || 0) + 1
      }
      for (const pick of match.picks) {
        pickCounts[pick] = (pickCounts[pick] || 0) + 1
      }
    }

    return NextResponse.json({
      teamId,
      totalMatches: allMatches.length,
      matches: allMatches,
      statistics: {
        bans: Object.entries(banCounts)
          .map(([map, count]) => ({ map, count }))
          .sort((a, b) => b.count - a.count),
        picks: Object.entries(pickCounts)
          .map(([map, count]) => ({ map, count }))
          .sort((a, b) => b.count - a.count)
      }
    })
  } catch (error) {
    console.error('Scraping error:', error)
    return NextResponse.json({ error: 'Failed to scrape VLR.gg' }, { status: 500 })
  }
}
