import { NextResponse } from 'next/server'

// Search for teams on VLR.gg
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get('q')

  if (!query || query.length < 2) {
    return NextResponse.json({ teams: [] })
  }

  try {
    // Fetch VLR rankings page which lists top teams
    const regions = ['na', 'eu', 'ap', 'br', 'kr', 'jp', 'latam', 'cn']
    const allTeams: Array<{
      id: string
      name: string
      logo: string
      country: string
      region: string
      rank: string
    }> = []

    // Search across regions
    for (const region of regions.slice(0, 3)) {
      try {
        const res = await fetch(`https://www.vlr.gg/rankings/${region}`, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
          }
        })
        
        if (!res.ok) continue
        
        const html = await res.text()
        
        // Parse team entries from rankings
        // Match pattern: team ID in href, team name, logo
        const teamRegex = /href="\/team\/(\d+)\/[^"]*"[^>]*>[\s\S]*?<div class="rank-item-team-name">([^<]+)<\/div>/g
        const logoRegex = /class="rank-item-team"[^>]*>[\s\S]*?<img[^>]*src="([^"]+)"/g
        
        let match
        while ((match = teamRegex.exec(html)) !== null) {
          const teamId = match[1]
          const teamName = match[2].trim()
          
          // Only include teams matching query
          if (teamName.toLowerCase().includes(query.toLowerCase())) {
            allTeams.push({
              id: teamId,
              name: teamName,
              logo: '',
              country: '',
              region: region.toUpperCase(),
              rank: ''
            })
          }
        }
      } catch (err) {
        console.error(`Error fetching ${region} rankings:`, err)
      }
    }

    // Also try direct search on VLR
    try {
      const searchRes = await fetch(`https://www.vlr.gg/search/?q=${encodeURIComponent(query)}&type=teams`, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      })
      
      if (searchRes.ok) {
        const searchHtml = await searchRes.text()
        
        // Parse search results
        const searchRegex = /href="\/team\/(\d+)\/([^"]+)"[^>]*>[\s\S]*?<div[^>]*>([^<]+)<\/div>/g
        let match
        
        while ((match = searchRegex.exec(searchHtml)) !== null) {
          const teamId = match[1]
          const teamName = match[3].trim()
          
          // Avoid duplicates
          if (!allTeams.some(t => t.id === teamId)) {
            allTeams.push({
              id: teamId,
              name: teamName,
              logo: '',
              country: '',
              region: '',
              rank: ''
            })
          }
        }
      }
    } catch (err) {
      console.error('Search error:', err)
    }

    // Remove duplicates and limit results
    const uniqueTeams = allTeams
      .filter((team, index, self) => 
        index === self.findIndex(t => t.id === team.id)
      )
      .slice(0, 20)

    return NextResponse.json({ teams: uniqueTeams })
  } catch (error) {
    console.error('Team search error:', error)
    return NextResponse.json({ error: 'Failed to search teams' }, { status: 500 })
  }
}
