import { NextResponse } from 'next/server'

const VLR_API_BASE = 'https://vlrggapi.vercel.app'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const region = searchParams.get('region') || 'na'

  try {
    const response = await fetch(`${VLR_API_BASE}/rankings?region=${region}`, {
      next: { revalidate: 3600 }
    })
    
    if (!response.ok) {
      throw new Error(`VLR API returned ${response.status}`)
    }
    
    const data = await response.json()
    
    if (data.data) {
      const teams = data.data.map((team: {
        rank: string
        team: string
        logo: string
        country: string
        record: string
        earnings: string
        last_played: string
        last_played_team: string
      }) => ({
        rank: team.rank,
        name: team.team,
        logo: team.logo?.startsWith('//') ? `https:${team.logo}` : team.logo,
        country: team.country,
        record: team.record,
        earnings: team.earnings,
        lastPlayed: team.last_played,
        lastOpponent: team.last_played_team
      }))
      
      return NextResponse.json({ teams, region })
    }

    return NextResponse.json({ teams: [], region })
  } catch (error) {
    console.error('VLR Rankings error:', error)
    return NextResponse.json({ error: 'Failed to fetch rankings' }, { status: 500 })
  }
}
