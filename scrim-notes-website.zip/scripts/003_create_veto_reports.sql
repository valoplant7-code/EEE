-- Create veto_reports table
CREATE TABLE IF NOT EXISTS veto_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_name TEXT NOT NULL,
  team_name TEXT NOT NULL,
  opponent TEXT,
  match_type TEXT,
  tournament TEXT,
  date_from DATE,
  date_to DATE,
  matches_analyzed INTEGER DEFAULT 0,
  status TEXT DEFAULT 'complete',
  filters JSONB,
  results JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE veto_reports ENABLE ROW LEVEL SECURITY;

-- Allow all operations (no auth for now)
CREATE POLICY "Allow all operations on veto_reports" ON veto_reports FOR ALL USING (true) WITH CHECK (true);
