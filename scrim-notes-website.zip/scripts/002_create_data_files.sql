-- Store uploaded scrim data files with parsed stats
create table if not exists public.scrim_data_files (
  id uuid primary key default gen_random_uuid(),
  file_name text not null,
  upload_date timestamp with time zone default now(),
  date_start date not null,
  date_end date,
  maps text[] default '{}',
  teams text[] default '{}',
  match_count int default 0,
  stats jsonb default '{}',
  raw_data jsonb default '{}',
  created_at timestamp with time zone default now()
);

-- Enable RLS
alter table public.scrim_data_files enable row level security;

-- Public access policy
create policy "Allow all operations on scrim_data_files" on public.scrim_data_files for all using (true) with check (true);
