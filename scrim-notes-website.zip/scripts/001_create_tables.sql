-- Scrim Notes table for VOD review notes
create table if not exists public.scrim_notes (
  id uuid primary key default gen_random_uuid(),
  round_number int not null,
  our_score int not null default 0,
  enemy_score int not null default 0,
  note text not null,
  map text,
  vod_url text,
  timestamp_seconds int,
  author text default 'Anonymous',
  created_at timestamp with time zone default now(),
  note_date date default current_date
);

-- Scrim matches table for tracking overall match data
create table if not exists public.scrim_matches (
  id uuid primary key default gen_random_uuid(),
  opponent_name text not null,
  match_date date not null default current_date,
  map text not null,
  our_score int not null default 0,
  enemy_score int not null default 0,
  result text generated always as (
    case 
      when our_score > enemy_score then 'win'
      when our_score < enemy_score then 'loss'
      else 'draw'
    end
  ) stored,
  vod_url text,
  notes text,
  created_at timestamp with time zone default now()
);

-- Player stats per match
create table if not exists public.player_stats (
  id uuid primary key default gen_random_uuid(),
  match_id uuid references public.scrim_matches(id) on delete cascade,
  player_name text not null,
  agent text not null,
  kills int not null default 0,
  deaths int not null default 0,
  assists int not null default 0,
  acs int default 0,
  adr float default 0,
  first_kills int default 0,
  first_deaths int default 0,
  created_at timestamp with time zone default now()
);

-- Enable RLS
alter table public.scrim_notes enable row level security;
alter table public.scrim_matches enable row level security;
alter table public.player_stats enable row level security;

-- Public read/write policies (no auth required for simplicity)
create policy "Allow all operations on scrim_notes" on public.scrim_notes for all using (true) with check (true);
create policy "Allow all operations on scrim_matches" on public.scrim_matches for all using (true) with check (true);
create policy "Allow all operations on player_stats" on public.player_stats for all using (true) with check (true);
