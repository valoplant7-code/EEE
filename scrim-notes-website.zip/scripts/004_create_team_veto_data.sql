-- Table to store teams from VLR
CREATE TABLE IF NOT EXISTS vlr_teams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vlr_id TEXT UNIQUE,
  name TEXT NOT NULL,
  short_name TEXT,
  logo_url TEXT,
  region TEXT,
  last_updated TIMESTAMPTZ DEFAULT NOW()
);

-- Table to store match veto data
CREATE TABLE IF NOT EXISTS vlr_match_vetos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vlr_match_url TEXT UNIQUE,
  match_date DATE,
  event_name TEXT,
  team1_id UUID REFERENCES vlr_teams(id),
  team2_id UUID REFERENCES vlr_teams(id),
  team1_name TEXT,
  team2_name TEXT,
  team1_score INT,
  team2_score INT,
  winner TEXT,
  match_type TEXT, -- BO1, BO3, BO5
  maps_played JSONB, -- [{map, team1_score, team2_score, picked_by, decider}]
  veto_sequence JSONB, -- [{action: 'ban'|'pick', team, map, order}]
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for faster team lookups
CREATE INDEX IF NOT EXISTS idx_vlr_match_team1 ON vlr_match_vetos(team1_name);
CREATE INDEX IF NOT EXISTS idx_vlr_match_team2 ON vlr_match_vetos(team2_name);
CREATE INDEX IF NOT EXISTS idx_vlr_match_date ON vlr_match_vetos(match_date);

-- RLS
ALTER TABLE vlr_teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE vlr_match_vetos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all on vlr_teams" ON vlr_teams FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on vlr_match_vetos" ON vlr_match_vetos FOR ALL USING (true) WITH CHECK (true);
