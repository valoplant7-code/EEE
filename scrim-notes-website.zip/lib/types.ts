export interface ScrimNote {
  id: string
  round_number: number
  our_score: number
  their_score: number
  content: string
  timestamp?: string
  vod_url?: string
  map?: string
  author: string
  created_at: string
}

export interface ScrimMatch {
  id: string
  match_date: string
  opponent_name: string
  map: string
  our_score: number
  enemy_score: number
  result: 'win' | 'loss' | 'draw'
  vod_url?: string
  notes?: string
  created_at: string
}

export interface PlayerStat {
  id: string
  match_id: string
  player_name: string
  agent: string
  kills: number
  deaths: number
  assists: number
  acs: number
  adr: number
  first_kills: number
  first_deaths: number
  created_at: string
}

export const VALORANT_MAPS = [
  'Ascent',
  'Bind',
  'Breeze',
  'Fracture',
  'Haven',
  'Icebox',
  'Lotus',
  'Pearl',
  'Split',
  'Sunset',
  'Abyss'
] as const

export const VALORANT_AGENTS = [
  'Astra', 'Breach', 'Brimstone', 'Chamber', 'Clove', 'Cypher',
  'Deadlock', 'Fade', 'Gekko', 'Harbor', 'Iso', 'Jett',
  'KAY/O', 'Killjoy', 'Neon', 'Omen', 'Phoenix', 'Raze',
  'Reyna', 'Sage', 'Skye', 'Sova', 'Viper', 'Vyse', 'Yoru'
] as const
